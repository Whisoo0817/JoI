# 모델 내 bounded ACTION 동치: 증명 의무와 코드 대응

2026-09-07. 사용자 TODO 1(입력 이산화·BFS·병합·시간 점프)의 검토 결과다.
현 계약은 `strict-two-valued-v1` BOOL과 정수 표현까지 포함한 DOUBLE 입력이다.
이 문서는 수작업 증명과 구현 검토를 연결한다. Python 전체의 기계 검증이나
테스트에 의한 모든 프로그램 열거를 주장하지 않는다.

**2026-09-08 H 없는 확장:** [UNBOUNDED_TIME.md](UNBOUNDED_TIME.md)의 비관찰 구간
생략 보조정리와 정확한 상대 시간 관계를 기존 O1–O6에 추가한다. 그래프 폐쇄 또는
모든 기호 경로 종료로 무한 시간 명제를 인증한다. 고정 입력 반례 가속은 보편 명제의
근거에서 제외한다. 아래 B(H)는 명시적 bounded 요청에 대한 기존 정리로 유지한다.

**후속 산술 확장:** [SMT_VERIFICATION.md](SMT_VERIFICATION.md)는 같은 B(H)에
대해 typed symbolic 실행·분기 경로 보존·IEEE 숫자·문자열 과대근사·UNSAT/반례 재생의
추가 의무를 연결한다. 1차원 입력 대표값의 정확성을 산술식까지 주장하지 않는다.
기존 BFS/기호 값 흐름과 SMT는 서로 다른 충분조건이며 각각의 전제 내에서만 인증한다.

**추가 완료 — symbolic-value-flow-v1:** 큰 관찰 입력/일반 문자열을 쓰는 순차
one-shot은 [기호 값 흐름 증명](SYMBOLIC_VALUE_FLOW.md)의 표현식·실행·이력 보존
의무로 B(H)를 인증할 수 있다. 이 경로는 값 열거 대신 보편 기호를 사용하며,
아래 concrete BFS 정리와 구별되는 충분조건이다. 다른 경우의 기존 의무는 유지한다.
자동 입력의 조합 상한 초과 시에도 같은 기호 인증 경로를 선택한다. 이는 전략 선택
조건의 확장이며 증명 의무를 완화하지 않는다. 명시 유한 domain은 자동 전체 catalog
기호 도메인으로 승격하지 않고 기존 cap/범위를 유지한다.

## 1. 증명할 명제와 모델의 경계

P, Q는 고정 binding/inventory와 서비스 snapshot에 접지된 IR/JoI 프로그램이다.
초기 내부 GV 값은 I, 외부 입력의 허용 집합은 U=∏U_k, 시작 시각은 t₀,
입력 주기는 양의 정수 Δ, 검증 길이는 유한한 정수 H≥0이다.
초기 장치 상태는 첫 입력 u₀이며 모든 U의 조합에 포함된다. 실행 중 binding은
바뀌지 않는다. 내부 변수는 각 프로그램의 초기화 규칙으로 시작한다.

입력은 t₀+kΔ에서 임의의 U 원소를 선택하고 사이에는 유지된다. 그 시각에
timer가 만료하면 새 입력을 먼저 반영한다. ACTION은 논리 시각과 호출 그룹의
열이다. 한 호출에서 독립 기기 순열만 무시하고 대상·동작·인자·중복·명시 순서를
보존한다. 종료 자체는 ACTION이 아니며, 이후 무행동인 흡수 상태다.

명제 B(H): 아래 의무 O1–O6 아래 `EQUIV-BOUNDED(H)`를 반환했다면

```
∀ i∈I, ∀ u∈U^(floor(H/Δ)+1):
  Obs(Trace(P,i,u)|[t₀,t₀+H]) = Obs(Trace(Q,i,u)|[t₀,t₀+H]).
```

명시 input_domains를 주면 U는 그 목록이다. 자동 입력 모델이면 U는 선언한
타입·범위·정밀도·결측 계약 전체이고 탐색은 대표 R을 쓴다. 명시한 subset을
전체 카탈로그 도메인으로 승격하지 않는다. 100ms는 외부 입력 모델의 Δ이며
timer 반올림 단위가 아니다. 실제 장치/서버의 측정은 이 모델 명제의 전제가 아니다.

## 2. O1 — 입력 대표가 모든 허용 값을 포괄한다

각 k에 대해 두 프로그램의 전체 단항 술어를 P_k로 모은다. v~w를 모든
P_k의 진리값이 같은 관계로 정의한다. 요구사항은 (i) R_k⊆U_k와
(ii) 모든 v∈U_k에 대해 v~r인 r∈R_k가 존재하는 것이다.

- BOOL/BOOLEAN: U=R={false,true}. clock.isholiday도 동일하다.
- ENUM/검토한 Forecast 문자열: 유한한 전체 members와 비BOOL None에서
  진리벡터당 하나를 남긴다. 따라서 비어 있지 않은 모든 동치류를 만난다.
- INTEGER: 정수선의 비교 경계 floor(c) 주변과 0 주변, 범위 끝점을 포함한다.
  각 비교의 참값은 경계에서만 달라진다. 비어 있지 않은 정수 구간에는 경계
  이웃이나 끝점이 존재하므로 모든 진리벡터에 증인이 있다.
- DOUBLE 조건 전용: 0.1 격자에서 같은 논증을 적용한다. 분할 경계는 실제
  비교 상수의 Fraction으로 계산하고 자동 비교 상수는 |c|≤10¹²로 제한한다.
  이 범위에서 float 격자점은 순서를 보존한다. 허용 int의 숫자 비교 결과는
  해당 float 격자점 또는 같은 꼬리 구간과 같다. 타입/문자열 변환이 쓰이면
  조건 전용 축소를 적용하지 않는다.
- STRING: 빈 문자열, 각 비교 상수 s와 즉시 후속 문자열 s+NUL이 최소점,
  비교점, 비어 있지 않은 사전식 구간/꼬리를 대표한다.
- untyped synthetic/GV 모델은 INPUT_COVERAGE.md §1–3의 명시 계열을 따른다.

원값이 ACTION이나 축소 불가능한 계산에 도달하면 R_k=U_k가 필요하다.
BOOL/유한 members는 전체 열거한다. 작은 bounded numeric도 전체 열거한다.
DOUBLE의 허용값은 float 격자뿐 아니라 같은 범위의 int를 포함한다. 따라서
exact 경로는 **정수 표현, float 표현, +0.0/-0.0, 비BOOL None**을 모두 포함한다.
큰/무경계 numeric과 관찰되는 임의 문자열은 명시 도메인을 요구한다.

구현: `ServiceModel.domains/representatives`, `input_coverage.representatives`,
`runner_input_domains`, `validate_domains`. 이산화는 두 프로그램의 술어를
합친 뒤 다시 구성한다. 이전 각자 대표 집합의 합집합만 쓰지 않는다.

### 이번 검토에서 발견하고 수정한 위반

`Light.CurrentBrightness`는 DOUBLE이고 int 1도 허용한다. IR은 값이 1이면
`Speak("value=$x")`, 후보는 `Speak("value=1.0")`라고 하자. 입력 1.0에서는
같지만 1에서는 `value=1`과 `value=1.0`으로 다르다. 기존 자동 exact 도메인은
float만 생성하여 EQUIV-BOUNDED를 냈고, 명시 [1]에서는 DIVERGE를 냈다.
정수 표현을 exact 도메인에 추가한 뒤 자동 경로에서도 재생 확인된 DIVERGE다.
조건 전용 대표 축소나 ACTION 수치 동등 관계를 바꾼 수정이 아니다.

## 3. O2 — 입력 치환이 ACTION과 미래 실행을 보존한다

외부 값의 출처를 식 잎에 붙이고, 변수/GV 복사에도 그 출처를 보존한 관계를
생각한다. 프로그램에 이 출처를 실제로 저장할 필요는 없다. 원본 v와 대표
ρ_k(v)를 저장한 두 실행을 연결하는 증명용 관계다.

Collector는 모든 분기와 모든 대입(초기화 포함)의 정의를 합친다. 한 실제
대입 이력은 정의 그래프의 경로이고, 외부 잎으로 가는 경로에는 단순 경로가
존재한다. 방문 집합으로 cycle만 끊는 탐색은 출처를 잃지 않는다. 상수와
bool 결과는 값 그대로, 미초기화는 None으로 포함한다.

문장별 보존: 복사는 출처 관계를 유지한다. 단항 비교는 O1의 진리벡터로
보존된다. bool 합성은 같은 bool 결과를 낸다. 원값 사이 비교·계산·ACTION은
관련 출처가 exact이므로 실제 값과 타입까지 같다. 따라서 같은 분기/차단 위치,
같은 timer 생성/취소와 ACTION, 관계가 유지되는 다음 저장소를 얻는다.
문장 실행 길이 및 반응 횟수의 귀납으로 임의 이력 u와 ρ(u)의 trace가 같다.

query는 고정 device/member/타입 보존 리터럴 인자 key이고 같은 snapshot을
읽는다. 동적 인자와 미인증 AST는 거절하므로 수집되지 않은 응답을 임의
OpaqueToken으로 대체해 긍정 판정하는 경로는 인증 범위에 없다.

구현: `Collector.leaves/sources/compare/visit/run`, `joi_coverage`,
`ir_coverage`, `merged_coverage`, `initial_domains`, `check_supported_pair`.
한쪽이라도 쓰는 GV는 공통 초기 선택 뒤 양쪽 독립 저장소로 전개한다.
외부 입력으로 매번 덮어쓰지 않는다. D7 거절은 명시 도메인으로 우회하지 않는다.

## 4. O3 — 반응은 결정적이고 생략 구간은 무행동이다

고정 snapshot/time/state에서 각 순수 식의 결과와 다음 continuation은 유일하다.
유한 내부 전이는 차단·period 대기·종료까지 진행한다. 연료 초과/미지원/잘못된
ACTION 인자는 긍정 판정이 아니다. 파서/grounding/문장별 continuation의 관계는
FRONTEND_CORRECTNESS.md §2–5, 독립 실행 기준은 INTERNAL_SEMANTICS.md를 따른다.

반응 직후의 정상 정지 위치는 다음과 같이 전수 분류된다.

| 정지 위치 | 다시 달라질 수 있는 원인 | 구현 |
| --- | --- | --- |
| delay | 저장된 시작 시각+duration 만료 | IrRunner DELAY, Pause/OneShot __dstart |
| period | 직전 회차 완료+period 만료 | IR TOP/cN, Pause __next_run |
| wait | 새 입력, clock 변경, 활성 sustain/timeout 만료 | IR WAIT, JoI wait continuation |
| 종료 | 없음 | TerminalRunner 흡수 상태 |

조건이 같은 wait의 edge bit는 첫 평가에서 이미 갱신됐다. sustain은 시작/취소가
이미 반영됐고, timeout 시작도 이미 기록됐다. 따라서 다음 입력·clock 초 경계·
활성 만료의 최솟값 e 이전에 다시 실행하면 ACTION은 비고 상태는 그대로다.
`next_time`은 이 모든 사건을 포함한다. 보수적인 추가 poll은 무행동일 뿐이다.
양쪽이 모두 종료하면 더 볼 ACTION이 없고, 한쪽만 종료하면 다른 쪽은 계속 간다.
이벤트 개수의 귀납으로 매 ms 실행과 이벤트 실행의 timed trace가 같다.

## 5. O4 — bounded 상태 키는 미래를 잃지 않는다

정상 반응 이후의 product 상태를
`(A.vars,A.gv,B.vars,B.gv,absolute_time,held_input)`로 둔다. 현재 코드의
bounded key는 이 튜플을 전부 보존한다. 제어 위치, 중첩 가지 경로, 초기 회차 bit,
edge bit, 활성 timer, 종료 bit는 각 vars 사전에 포함된다. 내부 GV도 전부 남긴다.

`freeze_state`는 허용 스칼라/구조의 타입 태그를 붙이고 float.hex 및 Fraction의
분자/분모를 보존한다. 미지 객체는 거절한다. 키가 같으면 미래 반응에 쓰는 모든
값이 같다. 같은 snapshot/time에 대한 결정론성으로 다음 ACTION과 다음 키도 같다.
남은 유한 반응 수의 귀납으로 모든 후속 trace가 같으므로 하나만 전개해도 된다.

과거 parent/path와 initial_gv는 키에 없어도 된다. 현재 저장소가 이후 동작을
결정하며, 그 메타데이터는 재생 증인 복원에만 쓰인다. first_tick=True는 초기
전이에만 주고 저장된 노드의 모든 후속 전이는 False이므로 숨은 미래 상태가 아니다.
검증기가 기록하는 catalog 사용 목록/BOOL key cache도 실행 결과를 결정하는
프로그램 상태가 아니라 고정 프로그램에서 계산한 검사용 메타데이터다.

## 6. O5 — BFS는 모든 허용 이력을 포함한다

초기 전이는 모든 I×R 원소를 실행한다. 귀납적으로 길이 n인 임의 대표 이력의
상태가 큐에 있거나 O4의 동치 대표로 검사됐다고 하자. O3의 다음 이벤트가
입력 격자이면 R 전체를, 아니면 유지 입력 하나를 후속으로 실행한다. 그래서
그 이력의 모든 허용 다음 선택이 실행되거나 O4로 병합된다. 귀납으로 모든
유한 대표 이력을 포괄한다. 각 전이는 허용 선택만 사용하므로 가짜 이력도 없다.

`now > t₀+H`만 제외하므로 끝점 H의 ACTION도 검사한다. 모든 완결 경로가
차이 없이 끝나면 대표 이력 전체가 동치다. O1–O2를 합성하면 B(H)를 얻는다.
구현: `timed_product`의 combos/initial/transition/queue/seen/node_key.

## 7. O6 — 미완료와 동치를 구별한다; fixpoint는 별도다

입력 곱, 초기 곱, 전이 수, 상태 수 cap은 UNKNOWN/closed=False를 낸다.
예외·지원 거절은 gate에서 REFUSED이며 동치가 아니다. DIVERGE는 같은 초기 GV,
시간 원점, 유지 입력/이벤트 이력으로 재생해야 확인된 반례다.

무제한 모드에서는 clock 비사용 때만 내부 timer τ를 상대 나이 t−τ로 바꾸고
입력 위상을 보존한다. timer는 정수 ms의 Fraction이며 사용자 읽기와 이름 충돌을
거절한다. 같은 키 사이 시간차 c만큼 모든 deadline을 옮기면 같은 입력 선택에
대한 ACTION과 다시 같은 키를 얻는다. 이 양방향 시뮬레이션이 시간 이동 병합의
근거다. clock 사용 때는 절대 시각을 남긴다.

**유한한 몫 그래프가 반드시 생긴다고 증명한 것은 아니다.** 오래 남은 timer,
관찰 변수, 절대 clock 등으로 그래프가 닫히지 않을 수 있다. 실제로 큐가 닫힌
경우에만 EQUIV-FIXPOINT다. 길이 제한 없는 보장은 B(H)의 필수 전제가 아니다.

## 8. 증명과 검사의 역할; 남은 경계

- 수작업 증명: O1–O6의 추상화/전이/탐색 연결을 위에서 전개했다. 입력 모델은
  실세계 사실을 추정한 것이 아니라 사용자와 서비스 명세로 고정한 계약이다.
- 코드 검토: 각 의무의 구현 진입점, 전체 정상 정지 위치, state 구성 요소와
  거절 경로를 대조했다. O1의 DOUBLE 반례를 발견해 수정했다.
- 새 회귀: service model 2건, search correctness 5건. 메모 없는 매 ms 실행은
  9 program pairs×4⁴=2,304 이력, 별도 초기 GV×BOOL 이력 16+32=48개다.
  스케줄러/상태 키를 사용하지 않는 대조라 검색 공통 오류의 일부를 분리한다.
  구체 실행기와 관찰 함수는 공유하므로 E1을 대신하지 않는다.
- 이벤트 검사: delay/period/wait/sustain/timeout/edge/clock 정지 상태에서
  생략할 각 ms를 직접 실행해 무행동·저장소 동일성을 확인한다. 큰 시간 이동의
  저장소/활성 만료 대응도 검사한다. 유한 fixture 검사가 귀납 증명을 대체하지 않는다.

남은 신뢰 기반은 Python/수치·자료구조 연산, 파서/컴파일러/실행기의 수작업 대응과
실제 소스 구현이다. 전체 지원 언어를 proof assistant로 기계 검증한 상태는 아니다.
정의한 의미론에 대한 bounded verification의 수학적 연결과 구현 근거는 갖추되,
임의의 구현 버그가 없다는 주장과 구별한다. 다음 실무 작업은 정답 IR/catalog 6건,
입력 모델 한계 2건, 수정 소스/도메인을 동결한 평가다. 과거 v4 판정은 덮어쓰지 않는다.

## 2026-09-08: relational-state-v1 의무와 완료 근거

1. 실제 초기화 포함: 공통 정수 관계를 가정하기 전에 초기화·ACTION·갱신을 실행/비교.
2. 임의 정수에 대한 typed 연산 적합성: 구조 AST의 +/− 및 IntToText, 미구현 연산 fail-closed.
3. 매 전이의 ACTION 및 선택 변수 갱신 순서/post 관계 보존, 일반화는 그 이후에만 수행.
4. guard 전용 catalog 공동 분할 전체 곱집합, 동일 기호 조건 공유와 모든 분기 전개.
5. live snapshot 보존, period 경계 may-read-before-overwrite 분석으로 dead copy만 제거.
6. clock 없는 정확한 상대 타이머와 입력 위상 병합, 입력/만료 이벤트 전체 포괄.
7. 모든 의무 완료·큐 고갈·closed/complete를 갖춘 경우에만 무제한 성공; cap은 미완료.

[수작업 논증과 구현 대응](RELATIONAL_FIXPOINT.md)에 연결했다. 이는 Python 전체의
기계 검증 완료를 뜻하지 않는다.251회귀/개발20/E1 검사는 구현 근거이며 귀납 증명을
대체하지 않는다. corpus 신규 무제한 인증0과 개발 인증6을 분리해 논문에 기록해야 한다.

## 2026-09-08: catalog-range-v1 의무

[구현과 수작업 논증](CATALOG_RANGE_ANALYSIS.md): (1) catalog INTEGER bound의 실제 clock
modulo 구현 포괄성 및 derived clock 외부 덮어쓰기 금지, (2) 전체 구간에 대한 비교식 상수성,
(3) 부작용 없는 직접 읽기만 비교식 내부에서 제거, (4) 모든 다른 clock 읽기/저장값 보존,
(5) 기존 상대 타이머와 입력 위상 관계의 전이 보존 및 폐쇄. 원래 AST는 그대로 실행한다.
전체289 regression과 새388 평가를 완료했다. clock2건의 동등 인증은 자연어 자정 종료
의도가 올바르다는 보장이 아니다. 결과/증명 범위는 최신 HANDOFF와 새 보고서를 따른다.
