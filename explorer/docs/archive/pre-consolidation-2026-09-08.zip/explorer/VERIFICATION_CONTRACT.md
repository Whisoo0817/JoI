# 실행 가능한 검증 계약 — contract-v1

2026-09-07. [사용자 합의](../docs/VETS_verification_contract_decisions_2026-09-07.md)를
반영한 구현 인계다. **구현·회귀 결과와 전체 형식 증명 완료를 구분한다.**
실제 JoI 서버 측정은 현재 모델 내 ACTION 동치 검증의 필수 조건이 아니다.
최신 범위와 내부 실행기 검증은 [INTERNAL_SEMANTICS.md](INTERNAL_SEMANTICS.md)를 따른다.
[탐색 정리·전제·구현 대응](SEARCH_CORRECTNESS.md)에 bounded/fixpoint 논증과
전체 보장으로 연결하기 위해 남은 의무를 기록했다.
[파서·실행기 대응 논증](FRONTEND_CORRECTNESS.md)은 모델 내부 결정론성과 실제
서비스/플랫폼 적합성 전제를 분리한다. 이 문서 맨 아래 최신 인계부터 재개한다.

## 진입점과 모델

`gate.gate_pair` → `timed.timed_product`가 새 경로다. IR 문법, binding 형식,
고정 inventory는 유지한다. 내부 병렬 분기나 여러 시나리오 동시 실행은 도입하지 않았다.

```python
from explorer.gate import gate_pair
from explorer.input_model import decimal_domain

result = gate_pair(ir, binding, devices, joi_block,
    input_domains={"sensor.temperature": decimal_domain(0, 40)},
    input_step_ms=100, horizon_ms=5000)
```

위 0–40은 API 사용 예시이며 실제 센서 범위의 기본값이 아니다. 도메인의
키는 grounding한 장치 ID와 속성이다. 모델 소유자가 범위/값을 정하며,
검증기가 임의의 센서 최솟값·최댓값을 만들지 않는다. `None`을 도메인에 넣으면
결측도 검사한다. 모든 도메인 조합을 초기 상태와 이후 각 입력 시점에 열거한다.
GV 초기값은 `initial_gv_domains`로 지정한다. 생략하면 초기 GV의 실제 사용
술어를 함께 분할하고, 관찰값으로 흐르면 명시 초기 도메인을 요구한다.
쌍 중 하나라도 쓰는 GV는 초기 상태로 분류하며 외부 변화 축으로 덮어쓰지 않는다.

- **값:** float 입력은 0.1 배수. 도메인 밖 값이나 소수 둘째 자리 입력을
  반올림하여 검사하지 않는다. 지원하지 않는 정밀도는 모델 오류다.
- **외부 입력 시각:** 기본 `t0 + k × 100ms`. 모든 센서는 동시에 자유롭게
  변할 수 있고 값 변화 폭 제한은 없다. 입력 시점 사이의 값은 유지한다.
  이 모델의 보장은 100ms 사이의 짧은 펄스까지 포함하지 않는다.
- **실행 시각:** 시간 단위는 1ms. IR/code 양쪽의 delay·지속 조건·timeout·
  다음 회차 시각을 합쳐 처리한다. 150ms 만료를 200ms로 미루지 않는다.
  `clock.timestamp`는 기존 JoI 해석대로 정수 초이며 초 경계도 보존한다.
  외부 입력이 없는 만료 이벤트에서는 직전 입력을 사용한다.
  내부 타이머는 정확한 유리수 초로 저장하여 큰 시각에서도 ms를 보존한다.
- **동시 입력/만료:** 새 입력으로 조건을 평가하고 지속 조건이 깨졌으면 취소한다.
  무조건 delay는 취소하지 않는다.
- **period:** 회차가 완료된 시각부터 대기한다. 완료 1500ms, period 1000ms이면
  다음 회차는 2500ms다. wait/delay 중에는 기존 문장 위치부터 이어간다.
- **edge:** 첫 관찰 true는 발화한다. 이후 latch는 회차를 넘어 유지한다.
  latch 관찰은 해당 wait를 평가할 때 이루어진다. 다른 delay/period를 기다리는
  동안의 모든 edge를 별도로 수집하는 이벤트 구독 모델은 아니다.
- **ACTION:** 순차 호출 순서는 유지한다. 하나의 호출에서 펼쳐진 장치들은
  fanout 경계 정보를 갖는다. 그 안에서 독립 장치 간 순서만 무시하며 같은
  장치의 순서와 중복은 유지한다. 대상·동작·인자 값·타입을 보존한다.
  `1`/`1.0`은 같지만 `true`/`1`과 `1.01`/`1.0`은 구분한다.
- **종료:** 종료한 쪽은 흡수 상태다. 종료 플래그 차이만으로 반례를 만들지 않고
  상대의 이후 ACTION을 계속 검사한다. 초기 GV와 시작 시각도 반례에 저장한다.

## 입력 축소와 Speaker 반례

`Axes.observable_reads`는 IR/code의 ACTION 인자로 흐르는 외부 입력 출처를
기록한다. JoI 변수의 전이적 정의와 IR의 여러 read 정의를 추적한다.
이 출처의 유한 도메인이 없으면 `check_supported_pair`가 REFUSED한다.
도메인이 있으면 그 값들을 전량 열거한다. 따라서 `t<10: speak(t)`와
`t<10: speak(9)`는 `[9.0, 9.9, 10.0]` 모델에서 9.9로 구별된다.

도메인을 생략한 guard 전용 축은 기존 지원 검사와 새 입력 사용 인증을
통과한 경우에만 추론한다. [INPUT_COVERAGE.md](INPUT_COVERAGE.md)에 nullable
numeric/string 및 scalar equality 모델의 출처 포괄성, 공동 진리벡터 분할,
ACTION 보존과 BFS 연결을 논증했다. 이 모델이 실세계 센서 타입이라는
사실은 코드에서 증명하지 않는다. 혼합 타입 순서 비교, 큰 수치 비교 경계,
축소 불가능한 값 흐름은 명시 도메인을 요구한다. 변수 인자 query는 거절한다.
기존 joint/derived guard, arith-arg, observable-counter REFUSED는 유지한다.

## 탐색·판정

`timed_product`는 BFS로 도달 상태를 순회한다. 각 입력 시점에서 도메인 전체의
곱집합을 후속 상태로 만든다. 시간만 있는 이벤트는 유지된 입력으로 전개한다.

- bounded 탐색은 모든 구체 저장소와 절대 시각, 현재 입력을 키에 보존한다.
  `state_key.freeze_state`는 숫자 타입과 부호 있는 0도 구분한다. ACTION
  인자의 `1`/`1.0` 동치를 미래 문자열 출력이 가능한 저장소 병합에 쓰지 않는다.
- 무제한 탐색은 사용자 clock 읽기가 없을 때만 실행기 전용 timer를 정확한
  상대 밀리초로 바꾼다. 입력 격자 위상도 키에 남긴다. 사용자 변수·GV를
  포화하거나 지우지 않으며 IR와 코드 양쪽 timer의 상대 시각을 모두 보존한다.
- clock을 읽으면 절대 시각을 보존한다. 이 경우 무제한 탐색이 cap에 도달할 수
  있다. 해결되지 않은 시간 병합을 사용해 동치라고 판정하지 않는다.
- `ProductResult.claim`: `DIVERGE`, `EQUIV-BOUNDED`, `EQUIV-FIXPOINT`,
  `INCONCLUSIVE`. `horizon_ms`는 시작 ACTION을 포함하는 닫힌 범위 `[0,H]`다.
- gate의 `EQUIV`는 fixpoint 성공이고 bounded 성공은 별도 `EQUIV-BOUNDED`다.
  미지원/미완료는 배포 경로에서 REFUSED이며 product와 notes에 사유가 남는다.
  bounded 성공을 무제한 배포 승인으로 취급하지 않는다.

## 증명에 연결할 의무와 현재 근거

아래는 구현에 대응하는 증명 구조이며 논문 전체 정리의 완료 선언이 아니다.

1. **유한 입력 전개:** 선언된 각 축의 곱집합을 매 입력 시점 열거한다.
   초기 상태부터 경로 길이에 대한 귀납으로 선언된 모든 입력 이력을 포함한다.
   cap 이전에 일부만 실행했으면 결론은 INCONCLUSIVE다.
2. **이벤트 사이 생략:** 입력은 고정되고 실행기는 차단/period 대기 상태다.
   다음 입력·양쪽 만료·clock 경계 전에는 관찰과 실행 위치가 변하지 않아야 한다.
   `next_wakeup_ms`의 완전성이 이 축소의 핵심 의무다.
3. **상태 병합:** bounded 키가 같은 상태는 동일 시각·저장소·유지 입력을 갖는다.
   따라서 결정적인 실행기에서 동일 입력에 대해 동일한 후속 상태/관찰을 낸다.
   무제한 재기준화는 clock 비사용 및 내부 timer 이름 비충돌 하에서 시간 이동
   불변성을 요구한다. 예약된 내부 변수명 충돌은 거절한다.
4. **ACTION 몫 관계:** 한 호출의 독립 장치 순열만 같은 정규형을 갖고,
   각 장치의 순차 이력과 호출 경계/중복을 유지한다.
5. **입력 연결:** `INPUT_COVERAGE.md`에서 인증된 AST와 명시한 모델에 대한
   입력 추론의 포괄성·ACTION 보존을 논증했다. 전체 파서/grounding/구체 반응
   함수와 위 가정의 대응, 실제 JoI 적합성, 센서 도메인의 근거는 남아 있다.

## 검증과 재평가

`exact_timed_product`는 deadline scheduler를 사용하지 않고 매 1ms를 실제로
진행하는 독립 탐색 열거기다. 입력은 동일한 100ms 모델로 바꾼다. 구체 실행기와
ACTION 정규화는 공유하므로 둘의 일치는 탐색 축소 검증이며 런타임 적합성 증명은 아니다.
`tests/test_contract.py`에는 손으로 정한 기대 ACTION 시각 검사가 별도로 있다.

```sh
python3 -m explorer.tests.test_contract
python3 -m explorer.tests.test_input_coverage
python3 -m explorer.tests.test_soundness
python3 -m explorer.tests.test_exact_tick
python3 -m explorer.tests.test_mapping_response
python3 -m explorer.features
python3 -m explorer.ir_step
python3 -m explorer.contract_eval --manifest explorer/eval/contract_v1_development.json --output /tmp/contract-result.json
```

현재 회귀: 입력 포괄성 16, 새 계약 33, 기존 soundness 38, exact tick 9, mapping 3건 통과(총 99).
features 자가 점검과 IR 수동 trace 6/비교 8건도 통과했다.
`contract_eval`은 명시적 `contract-v1` manifest와 새 결과 파일을 요구하고,
모델 및 evaluator 소스의 SHA-256을 기록한다. 기존 v3/held-out 결과는 보존했다.
`product_runners`, `exact_tick_product`, `ab_eval`은 과거의 tick 모델 평가 도구다.
새 시간 계약의 결과와 혼용하지 않는다.

다음 필수 작업은 실제 JoI period 의미 확인, 지원 단편 증명, 센서 도메인 근거를
갖춘 새 평가 manifest 동결, held-out 재평가와 감사다. 초록 문구는 변경하지 않았다.

## 이전 compact 인계 — 최초 구현 직후

사용자 요청: “compact하고 이어서하게 기억해” (2026-09-07).
합의 기반 코드 반영까지 수행했으며, 다음 세션에서 처음부터 구현하거나
확정한 의미론을 다시 논의하지 않는다. README → 합의 기록 → 이 문서 순으로
현재 상태를 복원하고 아래의 남은 작업부터 이어간다.

1. 새 `timed.py`/`exact_timed.py`/`observation.py`와 실행기 변경을 검토하고,
   이 문서의 증명 의무를 실제 코드에 대조한다. 발견되는 결함은 수정한다.
   특히 deadline 누락, 구체 상태/시간 재기준화, 입력 출처 추적과 도메인
   포괄성, 초기 상태와 반례 재생의 일관성을 확인한다.
2. 실제 JoI의 period 기준과 blocking 재개 동작을 확인할 수 있는 런타임
   근거를 찾고 E1 적합성 검증을 보강한다. 현재 채택한 의미론이 실제 서버와
   일치한다고 확정된 것은 아니다. 근거 확보가 막히면 독립적으로 진행 가능한
   증명·평가 준비를 계속한다.
3. 지원 단편의 결정론성·입력 포괄성·시간 전개·상태 병합 정리를 작성한다.
   회귀 통과나 두 탐색기의 일치를 전체 formal verification 증명으로 쓰지 않는다.
4. 센서 도메인 근거와 시간 모델을 명시한 새 평가를 동결하고 held-out 재평가·
   결과 감사를 수행한다. 기존 v3 수치를 새 구현의 결과로 사용하지 않는다.

현재 작업 트리는 **미커밋** 상태이며 commit/push/배포는 하지 않았다.
기존 사용자 파일 `explorer/candidates/gemma4-26b-heldout-v1/`,
`explorer/candidates/gemma4-26b-heldout-v2/`,
`skill_result/06_manuscript/new_ovla_abstract_draft.md`는 보존한다.
새 CLI 개발 사례 3건은 모두 두 탐색기 판정이 일치했고 결과는
`/tmp/joi-contract-v1-development-20260907.json`에 있다. 이는 소규모 개발 확인이며
held-out 결과가 아니다. 이후 소스 주석 변경도 있었으므로 최종 evaluator 동결
시에는 새 결과 파일과 새 소스 해시를 생성한다.

사용자 최우선 목표는 논문에서 `formally verifies`를 뒷받침하는 보장과 효율이다.
BFS의 모든 허용 상태·입력 이력 포괄성을 유지한다. 산술식 거절·고정 binding은
확정 사항이다. 초록은 9월 11일까지 개선 후 미달하면 수정하며, 논문은 아직
미등록이고 사용자는 11일까지 등록할 계획이다. 등록을 다시 최우선으로 제안하지 않는다.

## 후속 검토 완료 — 2026-09-07

compact 이후 사용자의 “이어서 다음 작업 진행해”에 따라 탐색과 실행기 변경을
검토했다. 전체 증명·held-out 완료 선언은 아니다.

- bare `wait until(센서값)`, not/and/or, 변수 경유 조건의 입력 축 누락을
  재현·수정했다. IR에서는 bare register와 분기별 여러 READ 출처도 보존한다.
  truthy 조건과 수치 비교가 함께 있으면 0 경계가 병합된 입력 분할에 남는다.
- `1`/`1.0`을 저장한 뒤 문자열로 출력하는 반례에서 이벤트 BFS와 매 ms
  열거기가 모두 잘못 동치 판정하던 문제를 수정했다. `freeze_state`로 값의
  타입·구조·부호 있는 0을 보존한다. 명시 도메인의 구 tick product도 임의
  combo dedup을 하지 않게 했다. 손으로 정한 기대 출력으로 양쪽 공통 오류를 검사한다.
- holiday ACTION 입력 누락과 IR 파생 clock의 잘못된 외부 축 처리를 보완했다.
- 내부 시각과 IR duration은 `Fraction(ms,1000)`으로 정확히 표현한다.
  큰 시작 시각 `10**20+1`에서도 1ms delay/period와 fixpoint가 유지된다.
  예약 타이머 변수의 읽기만 하는 참조도 거절한다.
- [SEARCH_CORRECTNESS.md](SEARCH_CORRECTNESS.md)에 입력 전개, 이벤트 생략,
  구체 상태/시간 이동 병합, bounded/fixpoint 정리의 조건부 논증을 작성했다.
  입력 추론·파서/실행기 전체의 검증과 실제 런타임 적합성은 남아 있다.

83개 회귀(33+38+9+3), features 자가 점검, IR 손 trace 6/쌍 비교 8건 통과.
개발 manifest는 5건으로 확장했고, 독립적으로 정한 기대 판정까지 모두 맞았다.
결과: `eval/results/contract_v1_review_2026-09-07.json` (소스·manifest SHA 포함).
이 결과는 **개발 사례**이며 새 held-out 수치가 아니다.

실제 런타임 근거로 이전 `sensys/simulators/joi_simulator.py`를 확인했지만,
그 실행기는 periodic wait에서 현재 회차를 버리는 이전 의미를 사용한다.
따라서 새 차단 재개/period 계약에 대한 실제 JoI 적합성 근거로 사용할 수 없다.

**다음 시작점:** §7의 입력 추론과 실행 의미 연결 의무를 우선 닫고, 실제
JoI 스케줄러/실행 trace 근거를 확보한다. 새 held-out manifest는 입력 범위의
근거와 시간 모델을 명시한 뒤 동결한다. 현재 변경은 계속 미커밋 상태다.

## 이전 compact 인계 — 후속 검토 직후

사용자 요청: “compact하고 진행하게 기억해놔” (2026-09-07).
위의 최초 구현 직후 인계보다 **이 절과 후속 검토 완료 기록이 최신**이다.
다음 세션은 README → 사용자 합의 기록 → 이 문서의 후속 검토 기록 →
[SEARCH_CORRECTNESS.md §7](SEARCH_CORRECTNESS.md#7-아직-닫히지-않은-연결)을 읽고 이어간다.

**완료한 지점:** 합의 기반 구현, 첫 코드 검토와 재현된 오류 수정,
조건부 탐색 정리 작성, 회귀 83건과 개발 평가 5건 통과까지다.
`state_key.py`, `SEARCH_CORRECTNESS.md`, 새 개발 결과도 미커밋 변경에 포함된다.
개발 결과 파일의 evaluator/manifest SHA가 당시 실제 파일과 일치함을 확인했다.
`compileall`, `git diff --check`도 통과했다. compact 자체를 이유로 완료한
구현·검증을 처음부터 반복하지 않는다. 코드 변경이나 새 우려에 맞춰 재검증한다.

**바로 다음 작업:** 자동 입력 추론이 지원 단편의 모든 허용 값을 포괄하는지
구현과 증명을 연결한다. `explore.derive_axes`, `product.merge_axes`,
`features`, IR의 입력 출처 수집부터 살핀다. 특히 다음은 미완료 점검 대상이며
이미 확정된 결함으로 단정하지 않는다.

1. 타입 혼합·결측·문자열의 대표값 및 truthy/비교 조건 합성.
2. 깊거나 여러 정의를 갖는 변수 흐름, GV의 초기 상태/외부 입력/내부 쓰기
   구분, query의 입력 출처와 매개변수별 도메인 포괄성.
3. 파서·grounding·구체 실행기의 결정론성과 탐색 정리 전제의 대응.

결함은 최소 반례로 재현한 뒤 수정하고, 독립 기대 출력/판정과 회귀로 고정한다.
두 탐색기가 실행기·상태 인코딩을 공유하므로 두 판정의 일치만으로 공통 오류를
배제하지 않는다. 전체 formal 보장이 완성됐다고 표현하지 않는다.

실제 JoI 서버 스케줄러/실행 trace 근거를 확보하는 E1도 남아 있다.
기존 SenSys 시뮬레이터는 새 periodic blocking 의미의 정답이 아니다.
그 근거를 당장 구하지 못해도 입력 추론·증명·평가 준비는 계속 진행한다.
이후 입력 범위의 출처와 시간 모델을 명시한 새 held-out manifest를 동결하고
재평가·감사한다. 이전 v3 수치는 새 구현의 수치로 재사용하지 않는다.

사용자 합의는 유지한다: 외부 입력 기본 100ms / 실행·timer 정확도 1ms,
float 입력 0.1 단위, 고정 binding, 기존 산술식 REFUSED, 모든 허용 초기 상태와
입력 이력의 BFS 포괄. 초록은 9월 11일까지 개선 후 미달 시 수정한다.
commit/push/배포/등록/제출은 수행하지 않았다. 실행 중인 작업이나 agent는 없다.

## 최신 인계 — 입력 추론 포괄성 검토·논증 후

사용자 요청: “이어서 입력 추론의 전체 포괄성 검토, 증명 진행해” (2026-09-07).
현재 최신 상태는 이 절이다. 이전 인계의 입력 추론 미완료 항목은 아래처럼
진행했으며, 파서/실제 런타임 전제까지 완료된 것으로 확대하지 않는다.

### 완료

- `input_coverage.py`를 추가해 grounded JoI / 최종 IR 명령열의 모든 외부 읽기,
  모든 정의(`:=` 포함), bool 조건, query 결과, ACTION/GV 쓰기 출처를 수집한다.
  깊이 제한 없는 정의 그래프 순회와 다중 정의 합집합을 사용한다. 이 인증으로
  `derive_axes`/IR compile의 최종 cells를 만들고 쌍의 술어를 다시 공동 분할한다.
- None 누락, 문자열 사전식 중간 구간/센티널 충돌, 숫자·문자열 술어 덮어쓰기,
  숫자 외부 GV의 bool-only 축, := 관찰값 누락을 반례로 재현·수정했다.
- 쌍 중 하나라도 쓰는 GV는 초기 축으로 분류한다. 초기 값도 사용 술어로
  분할하며 관찰값으로 흐르면 명시 초기 도메인을 요구한다. 빈 초기 선언으로
  필요한 값을 누락하거나 외부 @gv 축으로 내부 값을 덮어쓰는 것을 거절한다.
- IR query 인자의 1.0→1 변환을 제거해 repr 기반 매개변수 키를 보존했다.
  인자별 읽기/무인자 property 대응을 검사했다. **변수 인자 query는 현재
  추가 REFUSED**: 기존 루프 범위 휴리스틱으로 전체 인자를 인증하지 않는다.
- 기존 D7 유지. := 안 산술의 무늬 검사 우회를 수정했다. 미지원 타입의 순서
  비교에서 gate가 TypeError를 REFUSED로 반환한다.
- [INPUT_COVERAGE.md](INPUT_COVERAGE.md)에 출처 포괄성, nullable numeric/string
  및 scalar equality의 대표 존재, ACTION/미래 상태 보존, 초기 GV와 BFS
  bounded/fixpoint 연결 논증을 작성했다. **수학적·조건부 논증, 비기계 검증**이다.
- 결측을 포함하니 기존 IR 자가 점검의 정상 flag/sustain 예제에도 실제 행동
  차이가 있었다. 각각 `not(t > 25)`, `m != false`로 고쳤고, 원래 flag 오류는
  `높음 → None → 높음` 손 trace와 회귀로 보존했다.

### 보장 범위와 새 제한

자동 모델의 numeric/string 계열은 비교 사용에서 제안한 **모델 전제**다.
실세계 센서 타입을 IR에서 증명해 얻은 것이 아니다. 숫자·문자열이 혼합된
순서 비교는 명시 도메인을 요구해 후보 때문에 기준 입력을 조용히 제외하지
않는다. 자동 numeric 비교 상수 절댓값 10¹² 초과도 명시 도메인 요구다.
이는 센서 값의 범위를 10¹²로 제한한다는 뜻이 아니다. 입력 원값이 관찰되거나
분할로 보존할 수 없는 관계/계산에 쓰이면 명시 유한 값 전량 열거를 사용한다.

### 검증 결과와 파일

- 새 입력 포괄성 16 + 계약 33 + soundness 38 + exact tick 9 + mapping 3 = **99건 통과**.
- features 자가 점검, IR 손 trace 6/쌍 비교 8 통과; compileall/diff check 통과.
- 개발 manifest: `eval/contract_v1_input_coverage_development.json` (기존 5 + 새 3).
- 최신 소스 결과: `eval/results/contract_v1_input_coverage_2026-09-07_v2.json`.
  **8/8 AGREE, 독립 기대 판정도 모두 일치**. manifest/evaluator SHA 포함.
  `_v2` 없는 같은 날짜 결과는 gate 오류 문구 호환 수정 전 소스 결과다.
  이전 review 결과/manifest도 보존했다. 새 held-out 결과가 아니다.
- `contract_eval`은 실제 초기 GV 도메인과 t0도 결과 모델에 기록한다.

### 바로 다음 작업

1. grounded AST/IR의 원시·합성 실행에 대한 결정론성/반응 함수 전제를
   파서·grounding·query/GV·제어 흐름 구현에 연결한다. 입력 인증 문서의
   전제를 반복해서 미완료라고만 기록하지 말고 각 전제를 검토·닫는다.
2. 실제 센서/서비스 및 초기 GV 도메인의 근거를 평가 manifest에 고정한다.
   추가 query 거절 등의 평가 가능 범위 변화도 분모에 남긴다. 현재 코드를
   이전 v3의 수치·도메인으로 동결된 구현처럼 취급하지 않는다.
3. 실제 JoI scheduler/trace의 E1 근거 확보와 새 held-out 평가·감사를 진행한다.
   기존 SenSys simulator는 새 periodic blocking의 정답이 아니다.

기존 합의(외부 입력 100ms, 실행 timer 1ms, float 0.1, 고정 binding, 모든
허용 초기 상태/이력 전수 검사)는 유지한다. 논문 초록·IR 스키마·binding
스키마는 바꾸지 않았다. 모든 변경은 미커밋이며 push/배포/등록/제출도 하지 않았다.

## 최신 인계 — 파서·grounding·실행기 검토 후

사용자 요청: “우리 다음 작업 진행해줘.” (2026-09-07).
이 절은 구현 검토 인계다. 이후 사용자 질의의 정정·compact 인계가 아래에 있다.

### 완료한 검토와 수정

- `FRONTEND_CORRECTNESS.md`: 파싱 우선순위, 고정 binding의 식/문장 보존,
  continuation과 PC/경로의 대응, 원시·합성 실행 결정론성, unique trace,
  입력 대표값/이벤트 생략/BFS 정리 연결을 조건부로 논증했다.
  기계 검증이나 실제 JoI 런타임 일치 증명으로 부풀리지 않았다.
- **재현·수정:** any가 첫 기기만 보던 오류, 두 장치의 같은 query가 같은
  서비스 입력으로 합쳐지던 오류, IR not 우선순위, unused query를 ACTION으로
  바꾸던 휴리스틱, 중첩 cycle 재진입 때 안쪽 count를 재사용하던 오류.
- query는 `CallExpr.input_key`로 실제 장치 ID를 보존한다. 입력 수집,
  실행, feasibility, domain audit도 같은 키를 사용한다. raw query 인자와
  계산된 인자 float→int 변환을 제거했다. 음수 float 리터럴의 -0.0도 보존한다.
- binding은 서비스/기기 존재·online·quantifier·빈 목록·사용 자리 수를 확인한다.
  #2 등 숫자 접미로 순서를 정하고, 단일 자리 재사용 규칙은 유지한다.
  쓰이지 않는 여분 서비스는 notes만 남긴다. 부유 후보 selector는 gate 거절.
- selector 전체 문법 검사, 불완전 조건식 거절, 정수 ms period 검사.
  `$Service.Member` 조건 읽기를 접지한다. IR 문자열 안 selector 텍스트와
  일반 ACTION 문자열 `Sensor.Value`는 데이터로 보존한다. template의 `$` 읽기만
  바꾸며 literal 본문까지 바꾸지 않는다.
- **추가 REFUSED:** backslash 문자열 escape, 표현식의 GV 쓰기, 다중 기기 query
  반환값, edge+양의 sustain 조합, foreach의 break/blocking/nesting/iterator 대입.
  미정의 조합을 임의 의미로 검증하지 않는다. 기존 D7 결정은 유지한다.

### 검증과 보존 파일

- 새 독립 기대 trace/값/거절 회귀 22건 + 기존 99건 = **121건 통과**.
  features, IR 손 trace 6/쌍 비교 8 자가 점검, compileall, diff check 통과.
- 개발 평가 **기존 8/8 + 새 4/4 AGREE**, 독립 기대 판정도 전부 일치.
  최종 소스/manifest SHA가 실제 파일과 일치함을 확인했다.
- 최신 결과는 `eval/results/contract_v1_input_coverage_2026-09-07_v5.json`과
  `eval/results/contract_v1_frontend_2026-09-07_v3.json`이다.
  새 manifest는 `eval/contract_v1_frontend_development.json`이다.
  더 낮은 suffix 결과는 중간 소스 기록이며 덮어쓰지 않았다.
  특히 input coverage v3의 2 REFUSED는 사용하지 않는 여분 binding까지
  거절하던 중간 검사 때문이다. 현재는 그 항목을 허용하고 기대 반례가 검출된다.
- 이 결과는 개발 회귀다. 실제 런타임 E1 또는 새 held-out 수치가 아니다.

### 다음 작업의 구체적 입구

1. `timeline_ir/catalog.py`, 서비스 스펙/skill 메타데이터에서 **query vs ACTION의
   실제 부작용, canonical 이름의 대응/충돌, named args의 정식 순서**를 확인한다.
   현재 위치 기반 query 분류와 JSON args 등장 순서는 모델 전제이며 실제 API
   적합성의 증명이 아니다. 이 연결이 이번 검토에서 명확해진 남은 의무다.
2. 같은 명세에서 센서/property/query/초기 GV의 타입·nullable·정밀도·도메인
   출처를 수집하고 새 manifest에 고정한다. 온도 범위 등을 임의로 사실화하지 않는다.
3. 실제 scheduler/trace E1: blocking 재개, completion-relative period,
   초기화(`:=` 중첩/조건부 배치 포함), edge·동시 입력·query 결측 규칙.
   기존 연구용 SenSys simulator를 새 계약의 정답 실행기로 사용하지 않는다.
4. 소스·서비스 모델·입력/시간 범위를 동결한 뒤 새 held-out 재평가·감사.
   새 query 키/거절 범위를 이전 v3 held-out 수치에 소급 적용하지 않는다.

사용자 합의와 초록은 유지했다. IR/binding 스키마는 변경하지 않았다.
모든 변경은 미커밋이다. 실행 중인 작업·subagent는 없다.

## 최신 compact 인계 — selector/query 질의와 실제 service list 확인

사용자 요청: “compact할테니 기억할거나 업데이트할거있으면 해. 없으면 말고”
(2026-09-07). 이 절이 최신이다. 위 구현·121건 회귀·개발 12건 검증을 다시
처음부터 하지 말고, 아래에서 구체화한 다음 작업으로 이어간다.

### 사용자와 나눈 설명 및 주의점

- 사용자는 단수 `(#Tag)`가 실제로 매칭 집합에서 랜덤 하나를 고르는 것으로
  이해하며, 같은 코드에서 두 번 호출하면 같은 기기로 가정하는지 질문했다.
  현재 구현은 **고정 inventory에서 Main이 정확히 하나면 그것, 아니면 첫 기기**를
  grounding 때 선택한다. 동일 태그 조합은 같은 기기를 가리킨다.
  BFS는 이 바인딩의 모든 상태·입력 이력을 조사하며 **가능한 모든 랜덤 바인딩을
  열거하지 않는다**. 실제 처음 선택된 binding을 검증기에 주는 경우와,
  호출마다 다시 랜덤 선택하는 경우는 다르며 후자는 현재 모델 밖이라고 설명했다.
  실제 플랫폼의 랜덤 시점/지속성은 확인되지 않았다. 질문을 새로운 의미론
  합의나 모든 binding 포괄 요구로 간주하지 않는다.
- any 오류는 **Explorer**가 첫 기기만 보던 구현 오류였다. 예: 첫 센서 20도,
  둘째 30도에서 any >25는 참이어야 한다. 실제 JoI가 잘못 실행한다는 뜻이 아니다.
- 사용자가 “query는 누가 정의했나, service list에 있나, forecast도 string
  반환 아닌가, 굳이 구분해야 하나”라고 지적했다. 파일 확인 후 정정했다:
  **query는 공식 service 종류가 아니라 기존 Explorer의 값 읽기 호출 명칭**이다.
  STRING은 반환값 타입이고, 입력 읽기와 ACTION은 검증에서의 역할이다.
  새 query 스키마/종류를 만들 필요 없이 실제 서비스 명세에 맞춰 처리해야 한다.
  “반환값을 변수에 받으면 무조건 입력 읽기”인 현재 규칙은 아직 검토·보완 대상이다.

### 이미 실제 파일에서 확인한 사실

- 명세: `files/service_list_ver2.0.7.json`.
  skills는 55개, functions는 총 114개다. 함수 필드는 id/descriptor/arguments/
  return_type, 일부 examples이며 별도 query/부작용 분류 필드는 없다.
- `WeatherProvider.Forecast`:
  `Hour` 인자 INTEGER, bound [0,120]. `return_type: {"type":"STRING"}`.
  descriptor는 N시간 뒤 WeatherEnum 값 이름 문자열(rain, clouds, clear 등)
  반환이라고 설명한다. 숫자 온도를 반환하는 실제 Forecast로 예시 들지 않는다.
  `GetWeatherInfo`도 STRING 반환이며 Lat/Lon DOUBLE 인자를 받는다.
  읽기 역할은 함수 설명에서 근거를 얻는 것이며 STRING/non-VOID만으로 부작용
  부재를 증명할 수는 없다.
- `timeline_ir/catalog.py`에 이미 다음 유틸리티가 있다:
  - `load_catalog`: 서비스별 functions의 순서 있는 인자 ID 목록과 values 타입.
    현재 이 인덱스에는 함수 return_type/descriptor를 보존하지 않는다.
  - `get_arg_order`: 서비스/함수 이름 정규화를 포함한 인자 순서 조회.
  - `value_domains`: values의 type/bound 및 ENUM의 format→members를 읽는다.
    함수 반환 도메인·nullable·정밀도 근거까지 해결하는 유틸리티는 아니다.
- 따라서 “우리 pipeline 전체가 service list를 안 본다”가 문제라는 설명은
  틀리다. **Explorer의 해석과 실제 카탈로그를 연결·검증하는 일**이 남은 것이다.

### 재개할 작업

1. 위 기존 catalog 유틸리티를 재사용해 Explorer의 named→positional 인자 순서,
   서비스/속성 이름, 입력 타입·범위를 실제 명세와 연결한다.
2. 함수 설명/반환 명세로 읽기와 동작을 검토하고, 반환값 대입 위치만으로
   ACTION을 제거하는 현재 규칙의 안전성을 해결한다. 공식 query 분류를
   새로 발명하거나 모든 non-VOID 함수를 부작용 없는 읽기로 취급하지 않는다.
3. 명세에 없는 nullable·0.1 정밀도·초기 GV 범위는 명시 전제로 남기고 출처와
   함께 manifest에 동결한다. 그 후 실제 runtime E1와 새 held-out 순서를 따른다.

이번 compact 준비는 문서만 수정했다. 직전 evaluator SHA
`3ae0c54ef3614c7e397c93d1c38fb7707101146d963c835bcc009ff1dbb96890`의 소스와
최신 개발 결과(v5 input coverage / v3 frontend)는 변경하지 않았다.
미커밋 작업과 사용자 파일은 보존하며 commit/push/등록/제출은 수행하지 않았다.

## 최신 인계 — 실제 서비스 명세 연결 완료 (2026-09-07)

사용자가 다음 작업 설명을 들은 뒤 “진행해”로 구현을 지시했다.
이 절이 위 compact 인계보다 최신이다. 상세 계약·포괄성 연결은
[SERVICE_MODEL.md](SERVICE_MODEL.md)를 읽는다.

### 이번에 완료한 작업

- `timeline_ir/catalog.py`에 lossless/hash 스냅샷 로더 추가. 기존 lowering index
  API는 그대로 둔다. `service_model.py`를 기본 prepare_pair/gate에 연결했다.
- 서비스/value/function 이름, alias 충돌, device capability, named args 집합,
  인자 타입/범위/ENUM 검사. **기존 binding 등장 순서로 접지한 뒤** 정식
  인자 순서로 재정렬하여 반복된 서비스 읽기의 장치가 바뀌지 않게 했다.
- 반환 대입만 보고 ACTION을 지우지 않는다. descriptor를 검토한 7개 읽기만
  표현식으로 허용하고 catalog hash에 검토를 고정한다. Toggle/SetVolume 등
  기기 제어+반환 대입은 REFUSED; 문장 호출은 ACTION 유지. 읽기 함수의 결과를
  버리는 문장 호출도 현재 거절한다. ACTION+return 지원을 완성한 것은 아니다.
- 실제 Forecast는 INTEGER Hour [0,120] → STRING이며 descriptor의 WeatherEnum
  15개 이름으로 반환 도메인을 연결했다. 일반 STRING 전체를 ENUM으로 만들지 않는다.
- 공동 술어의 대표값을 실제 catalog 타입·범위에서 새로 생성한다. 기존 mixed
  대표값의 필터링은 하지 않는다. 관찰되는 원문은 유한 작은 도메인 전체 열거,
  큰/무한 domain은 명시 선언 요구. None와 0.1은 모델 전제로 표시했다.
- CatalogRunner가 매 반응/재생의 동적 ACTION 인자도 검사한다. 두 timed engine도
  catalog 도메인 연결을 강제한다. 기존 D7 산술/결합식 거절은 그대로다.
- 기본 서비스 검사에 fallback 없음. 기존 synthetic 언어 fixture/manifests는
  `service_catalog=False`를 명시했고 출력도 실제 명세 검사 아님을 표시한다.
  실서비스 테스트는 기본값(True)로 별도 수행한다.
- evaluator 결과에 실제 member spec, catalog SHA, 모델 가정, input 도메인 출처를
  기록한다. 소스 해시는 추가 의존 `timeline_ir/catalog.py`도 포함한다.

### 검증 결과와 동결 파일

- 회귀 **142건 통과**: 기존 121 + 새 catalog 21. pytest는 환경에 없어서 각
  테스트 모듈의 기존 main/unittest 진입점으로 실행했다. 설치하지 않았다.
- features 자가 점검, IR 손 trace 6/쌍 비교 8 통과.
- 개발 평가 **20건 기대 결과 일치**: input coverage 8, frontend 4, catalog 8.
  catalog 중 2건은 기대 REFUSED, 나머지 6건은 두 검색기의 판정/기대 결과 일치.
- 최신 결과: `eval/results/contract_v1_input_coverage_2026-09-07_v6.json`,
  `contract_v1_frontend_2026-09-07_v4.json`,
  `contract_v1_service_catalog_2026-09-07_v1.json`.
- evaluator SHA: `6742008b73e0dbf4475b95386766534084a66f227667ce49a9f71031195dc946`.
- catalog SHA: `ac35c8b78c05ce7f379b7fe7b8dfa49b18172d68f69aec169169768c49e5a221`.
- `eval/results/catalog_preparation_2026-09-07_v1.json`은 현재 IR와 일치하는
  정답 캐시 178쌍의 준비 단계 검사만 기록한다: 175 PREPARED, 3 REFUSED.
  C01_015 GenerateImage 반환, C01_017 VOID Speak 반환 대입, C01_019 ChatWithAI
  반환이 거절 이유다. 이 수치를 동등성·D7 전체 통과·held-out 결과로 쓰지 않는다.
- 개발 중 null 비교(`query != None`)가 기존 derived-guard로 거절되는 것을
  확인했다. 기존 D7를 완화하지 않았다. 새 실제 Forecast 원문 전달 회귀는
  `w == "rain"`에서 Speak(w)로 검증한다.

### 다음 단계와 주의점

1. **실제 runtime E1 근거**: blocking/period, initialize once(중첩/조건부 포함),
   edge·동시 입력 우선순위, 실제 query 반환의 시점·지연·반복 호출 및 부작용.
   로컬 SenSys simulator를 새 blocking 계약의 정답으로 삼지 않는다.
2. nullable, DOUBLE 0.1, 초기 GV 범위, fixed binding/단수 랜덤 선택 지속성은
   명세로 해결되지 않은 전제다. 같은 읽기 key가 같은 입력 시점에는 같은 값을
   반환한다는 가정도 남긴다. 명시 subset은 전체 실제 도메인 포괄 주장과 다르다.
3. 이후 모델·소스·범위를 동결한 새 held-out 평가/감사. 과거 v3 수치 소급 금지.

사용자 합의·초록·IR/binding 스키마를 바꾸지 않았다. 미커밋 상태이며 사용자
candidates/와 abstract 초안 파일은 건드리지 않았다. 실행 중인 agent/작업은 없다.

## 최신 인계 — 목표 JoI 런타임 계약 확정 및 E1 개발 검사 (2026-09-07)

이 절이 위 서비스 명세 연결 인계보다 최신이다. 사용자는 실제 런타임 정책의
모호함을 가장 가능성 높고 검증에 유리하게 결정하도록 허용했으며, 실제 JoI
설계/구현을 논문 계획에 맞춰 따로 수정할 수 있다고 밝혔다. **실제 서버의 현재
동작을 알아낼 때까지 기다리는 방식으로 되돌아가지 않는다.**

### 확정한 기준

- [RUNTIME_CONTRACT.md](RUNTIME_CONTRACT.md)의 R1–R13을 목표 런타임 요구사항으로
  사용한다. 기존 시간·입력·관찰 합의 및 D7 거절은 유지한다.
- 검토된 읽기 함수는 고정 device/member/typed args key의 현재 snapshot을 즉시
  읽는다. 동일 snapshot의 같은 key는 같은 값. 비동기 응답은 허용 입력 경계에
  반영하고 결측은 None이다. 요청별 blocking/새 반환 상태를 추가하지 않는다.
- `:=`는 현재 코드와 같은 **초기 회차 전용 대입**으로 명확히 정했다. 첫 회차에서
  도달한 시점에 RHS를 읽는다. 첫 회차에서 건너뛴 조건부 초기화는 이후에도
  건너뛴다. delay 뒤 선언은 재개 시각 값을 읽는다. 선언별 첫 방문 초기화와
  다르며, first-iteration 비트 하나로 표현한다. loop 안의 반복 도달 경계도 문서화했다.
- 0.1 입력 격자/None/snapshot/고정 binding은 이제 목표 adapter의 요구사항이다.
  실제 배포 구현 확인 사실이 아니며, 초기 GV/명시 subset 근거를 대신하지 않는다.
- 실제 런타임과 네트워크 응답을 시험한 횟수는 0이다. 현재 workspace에서 실제
  hub scheduler 소스/명령 trace는 찾지 못했다. agent API client와 연구 simulator를
  실제 runtime 근거로 사용하지 않았다. 사용자의 후속 지시로 명세 확정은 가능하다.

### 완료한 개발 검사

- 새 `tests/e1_runtime_probe.py`: 고정 script/input schedule과 손으로 계산한
  기대 ACTION trace. catalog-backed code adapter를 1ms씩 재생하며 BFS/deadline
  scheduler/IR 동치 결과를 oracle로 사용하지 않는다. 런타임 독립 구현은 아니다.
- ACTION trace **14건 PASS**, Toggle 반환 대입 **1건 기대 REFUSED**.
- 지연 150→200ms, wait→if, `:=`→`=`의 프로그램 변이 **3건 검출**.
  실행기 자체에 오류를 주입한 검증을 완료했다는 뜻이 아니다.
- 로컬 ANTLR은 15개 script 전부 통과. `delay(1.5 SEC)`는 Explorer가 허용하나
  ANTLR은 INTEGER duration만 허용하는 차이를 확인했다. 정수 `1500 MSEC`로
  표현 가능하다. 현재 파서/생성 코드 수정은 하지 않았고 배포 정규화 의무로 남겼다.
- 기존 contract **33** + frontend **22** = **55건 재통과**. 기존 전체 142건을
  이번 턴에서 모두 재실행한 것은 아니다. production verifier 코드는 바꾸지 않았다.
- 결과: `eval/results/e1_target_runtime_2026-09-07_v1.json`.
  `actual_runtime_runs=0`, `e1_complete=false`를 명시했고 fixture/근거 hash를 기록했다.
  evaluator SHA는 이전과 같은 `6742008b73e0dbf4475b95386766534084a66f227667ce49a9f71031195dc946`.

### 다음 작업

1. 고정 명세에 대한 E1 독립 의미론 oracle/실행기 오류 주입 및 구성 경계 검사를
   보강한다. 손 trace 14건이 일반 구현 적합성 증명이나 전체 E1 완료를 뜻하지 않는다.
2. 실제 런타임 코드 작업이 가능해지면 R1–R13과 로그 요구사항에 맞춰 구현/대조한다.
   소스 위치 질문에 답을 기다려 다른 논문 작업을 멈출 필요는 없다.
3. 초기 GV/유한 subset의 평가 근거를 확정하고 새 모델 동결 held-out 평가·감사로
   진행한다. 기존 v3 수치 소급 금지, 초록은 사용자 일정대로 유지한다.

README, FRONTEND_CORRECTNESS, SERVICE_MODEL, E1 status를 동기화했다.
미커밋이며 실제 장치 제어/서버 요청/논문 제출은 수행하지 않았다.

## 최신 인계 — 내부 의미론 검증 및 범위 정정 완료 (2026-09-07)

**이 절이 가장 최신이다.** 사용자는 우리가 검증하는 것이 확정한 Timeline IR와
JoI 코드의 product-state ACTION trace 동치라고 재확인했고, 실제 기기/배포
런타임 측정 없이 필요한 내부 검증을 수행한 뒤 README와 작업현황에 기록하도록
지시했다. 실제 런타임 소스 위치/측정 질문으로 되돌아가지 않는다.

### 현재 보장과 필수 조건

- 확정한 의미론, 지원 단편, 고정 binding/inventory, 선언한 입력/초기 GV 모델에서
  모든 허용 이력의 timed ACTION trace 동치를 검증한다.
- 내부 실행기 적합성·입력 포괄성·BFS successor coverage·상태/시간 병합 보존 및
  bounded/fixpoint/미완료 구분이 필수다. 실제 JoI deployment conformance는
  **현재 모델 검증의 필수 전제가 아닌 선택적 보장 확장**이다.
- RUNTIME_CONTRACT.md의 규칙은 규범적 모델이다. 초록 강도/11일 일정, D7,
  외부 100ms/타이머 1ms, 0.1 lattice, 고정 binding 합의는 유지한다.

### 새 완료 근거

- `tests/semantic_reference.py`: 표준 Python만 사용하는 독립 generator 의미론.
  production 파서/식 evaluator/IR compiler/runner/관찰 정규화/입력 추론/BFS를
  재사용하지 않는다. `tests/e1_internal_conformance.py`가 별도 IR/JoI renderer로
  두 adapter를 준비해 각 1ms trace를 기준과 비교한다.
- 11개 프로그램 × 3⁵ 이력 = **2,673 paired histories / 5,346 trace 대조 일치**.
  0/100/200/300/400ms의 None/false/true 또는 None/clear/rain을 전체 열거한다.
  IR-only 중첩 finite cycle 재진입 **1개 이력도 일치**.
- 실제 실행기 함수의 delay 만료/period 계산에 주입한 오류 **2개 검출**.
  프로그램/예상 정답은 유지하고 메모리에서만 함수 교체 후 원복한다.
- 기존 **142건 전체 재통과**: contract33, soundness38, coverage16, frontend22,
  exact tick9, mapping3, catalog21. 기존 hand trace14/기대 REFUSED1/프로그램
  변이3의 근거도 유지한다. production verifier 코드는 이번 턴에 변경하지 않았다.
- 결과: `eval/results/e1_internal_semantics_2026-09-07_v1.json`.
  fixture/domain/horizon, 관찰 digest, 오류 주입 반례 및 소스/명세 hash가 있다.
  evaluator production SHA는 기존 `6742008b73e0dbf4475b95386766534084a66f227667ce49a9f71031195dc946`
  그대로다. 테스트/문서 변경을 별도 파일 hash로 기록했다.
- `INTERNAL_SEMANTICS.md`: 정확한 주장, 필요한 네 연결 의무, continuation
  대응/귀납 논증, 구성별 근거 및 테스트 범위를 한 곳에 정리했다.

### 한계와 다음 작업

- 이번 독립 oracle은 명시 kernel용이며 모든 지원 AST의 완전한 두 번째 실행기가
  아니다. sustain/timeout/edge/clock/초기화/GV/fanout 등은 기존 손 trace·회귀 및
  FRONTEND/INPUT/SEARCH 논증으로 보강한다. 전체 언어 기계 검증이나 모든
  프로그램의 테스트 완전성을 주장하지 않는다. 개발 E1을 전체 confirmatory
  실험 계획 완료로 바꾸어 적지 않는다.
- 다음은 현 모델의 입력/초기 GV와 후보 집합 동결 → 새 held-out 평가/감사 및
  지원/거절/미완료·시간/메모리 기록이다. 과거 v3 수치를 새 구현에 재사용하지 않는다.
- 필요하면 독립 kernel 밖 constructor 검사/오류 주입을 보강하되, 실제 배포
  측정 때문에 현재 모델 검증이나 논문 작업을 중단하지 않는다.

`joi/README.md`, `explorer/README.md`, FRONTEND_CORRECTNESS, SEARCH_CORRECTNESS,
INPUT_COVERAGE, SERVICE_MODEL, RUNTIME_CONTRACT, E1 status, 사용자 결정 기록을
동기화했다. 사용자 candidates/abstract 파일은 건드리지 않았고 미커밋 상태다.

## 최신 인계 — 동결 fresh-v4 평가·감사 완료 (2026-09-07)

**이 절이 최신이다.** 사용자의 “평가 조건을 동결한 새 held-out 평가 진행”에
따라 현재 구현을 고정하고 기존 388문제에 Gemma 코드를 새로 생성했다.
기존 v1/v2/v3 및 Qwen 후보는 수정하지 않았다. 새 디렉터리는
`candidates/gemma4-26b-contract-v1-fresh-v4/`다.

### 동결 및 실행

- `eval/frozen_contract.py`: protocol → 생성 → 준비/domain manifest → 독립
  프로세스별 Explorer/dense 1ms search. 모든 388 ID를 유지하며 각 엔진을
  따로 실행해 exact 미완료가 Explorer 판정을 가리지 않게 했다.
- `eval/results/contract_fresh_v4_2026-09-07_protocol.json`은 생성 전에 작성.
  실제 catalog, 100ms 외부 입력/정확한 1ms timer, nullable/0.1 lattice,
  고정 binding, 0–3,200ms inclusive, t0=2,419,200,000ms를 사용한다.
  입력은 양쪽 catalog-backed certified representatives/exact observable
  domain, GV는 규범적 predicate-family 모델. 필요한 explicit domain이
  없으면 REFUSED하며 유리한 subset을 새로 만들지 않았다.
- 각 엔진 200,000 states / 500,000 transitions / 100,000 input combinations,
  process wall 20초 / address space 768MiB. 단일 평가 worker, Explorer 후 exact.
  생성은 local Gemma-4-26B AWQ, 기존 e3 helper, workers4/행별120초, seed미지정.
- 83개 소스/명세/dataset/catalog hash 및 원본 ZIP을 보관했고 실행 전후 검증.
  production evaluator SHA는 `6742008b73e0dbf4475b95386766534084a66f227667ce49a9f71031195dc946`
  그대로다. 이 절/README는 실행 후 변경했으므로 재현 시 보관 ZIP을 사용한다.
  로컬 hash 연속성이지 hermetic 실행/외부 인증은 아니다.

### 결과와 정확한 분모

- **388 = bounded 동등 203 + 재생 확인 반례 77 + Explorer 미완료 1 +
  준비 REFUSED 46 + 생성 실패 59 + 파싱 오류 2.** 생성 실패는 모두
  `device_not_connected`이며 파이프라인 결과를 재시도/제외하지 않았다.
- 두 엔진 완료 **267 = 동등 191 + 반례 76**, 전부 판정 일치. 불일치 0.
  exact 미완료 **14**: Explorer 동등12/반례1/미완료1. 완료 못한 exact를
  정답으로 추정하거나 false-accept 분모에 넣지 않는다. 반례77 전부 재생 확인.
- Explorer 미완료는 C01_014: PM10 exact observable domain 100,003개가
  사전 100,000 조합 한도를 넘었다. 결과를 보고 한도를 올려 재실행하지 않았다.
- 생성899초, 평가194.794초. 탐색281건 Explorer search median0.406ms /
  p95 107.858ms / max3.424s. 준비/프로세스 시작 포함 wall median69.857ms /
  p95 194.962ms / max3.583s. process peak RSS max92,900KiB.
  단순 one-shot이 많고 median exact가 더 작아 전체에 대한 일괄 speedup을
  주장하지 않는다. 동등 완료191건의 비교 수치와 전체 실패도 metrics에 있다.

### 증거 한계와 다음 작업

- 정상 생성329건 중 **308건이 같은 문제의 과거 v3 script와 완전히 동일**.
  21건만 달랐다. 새로운 호출 표본이지 388개 새로운 문제/미노출 코드가 아니다.
  전부 유지했으며 post-hoc 중복 제거 수치를 confirmatory 성능으로 쓰지 않는다.
- 감사는 **supports_exploratory_follow_up**, standalone self-review다.
  현재 구현의 재평가/탐색 차등 근거로 사용한다. shared runner/observation,
  익숙한 corpus, 3.2초 밖의 행동, 충분한 독립 label 부재를 명시했다.
  READY281건에 nonempty initial GV model이 없어 이번 corpus가 초기 GV 검사
  범위를 별도로 강화했다고 주장하지 않는다.
- 다음은 같은 저온도 모델을 반복 생성하기보다 중복·개발 노출을 구분한 별도
  표본과 긴 시간 범위/완료율 검사를 설계하는 것. 코드 수정이 필요하면 새
  버전·새 protocol을 만들고 이번 결과를 덮어쓰지 않는다. 배포 측정은 필수 아님.

### 파일과 확인

- 설명: `eval/CONTRACT_FRESH_V4.md`.
- 원본: `eval/results/contract_fresh_v4_2026-09-07_{protocol,manifest}.json`,
  `_sources.zip`, `_generation.log`, `_evaluation.log`, 그리고 같은 prefix
  디렉터리의 `case_outcomes.jsonl`, `summary.json`, `metrics.json`.
- 감사: `eval/results/contract_fresh_v4_2026-09-07_audit/results-audit.{json,md}`;
  `research-results-auditor` 구조 validator 통과. 구조 검증을 독립 과학 검증과
  동일시하지 않는다. 새 reporter는 `eval/report_frozen.py`.
- 개발 smoke: 기존 v3 5건(2일치/2거절/1생성실패), catalog fixture6건 ×
  2엔진 worker/direct 판정12개 일치. production을 바꾸지 않아 기존142건을
  반복 실행하지 않았다. 새 두 script syntax/소스보관hash/77replay/분모 확인.
- 새 하네스 최초 relative-path 오류는 protocol 생성 전 수정했다. 후보/평가
  실행 실패가 아니며 후속 missing-file 명령도 산출물 없이 실패했다.
  최종 보고서 중복 수치 해설 보강은 원시 결과·metrics를 바꾸지 않았다.

README 두 곳과 이 인계를 업데이트했다. 초록·논문 등록/제출·실제 장치 실행·
기존 후보·과거 결과 수정·commit/push는 하지 않았고 현재 변경은 미커밋이다.

## 최신 인계 — 준비 거절46건 원인 분류 완료 (2026-09-07)

사용자는 생성 실패와 Explorer 문제를 구분하라고 정정했고, 다음 TODO 중
1번인 REFUSED46건의 분류를 지시했다. **이 절이 최신이며 구현 수정 작업은
아직 시작하지 않았다.** 기존 평가 결과·dataset·catalog·후보·production은 유지했다.

- 생성 코드 측 계약/대상 불일치 **23**: capability9, 함수/enum2,
  다중 기기 scalar 읽기10, any ACTION2. 현재 선언 계약에서의 정적 불일치이며
  전체 JoI 언어의 보편적 불법 판정이나 새 DIVERGE label이 아니다.
- 정답 IR/카탈로그 불일치 **6**: C01_006/C01_017/C14_001/C14_005/C14_006은
  VOID 함수에 call.var 반환 대입. C03_002는 IsAvailable 필수 ServiceName 누락.
  생성된 IR이 아닌 기존 ir_gt이므로 Gemma만 탓하면 안 된다. ServiceName의
  catalog 타입 BOOL/설명 name 불일치도 명세 검토 대상. 수정은 하지 않았다.
- 합의된 미지원 **14**: 증가 counter modulo8, 효과 있는/미검토 반환 대입3,
  산술 관찰 인자1, 여러 기기 query 반환2. 기존 D7/거절 정책 유지.
- 입력 모델 **2**: C01_009 TemperatureWeather의 큰 **유한** DOUBLE 범위
  [-470,10000]에 0.1 격자104,701개(+결측/표현)가 필요해 자동 exact-domain
  cap 초과. C01_018 일반 STRING GetMenu 결과의 raw Speak 전달은 유한
  전체값 명세가 없음. 둘을 같은 원인이나 파서 버그로 취급하지 않는다.
- frontend 확장 후보 **1**: C18_006 `not(any(...).Motion)`의 맨 BOOL 읽기.
  명시 `== true`로 바꾼 **메모리 복사본**은 준비를 통과하고 horizon0에서
  replay-confirmed DIVERGE였다. 현 IR은 all binding에 not를 밖에서 적용해
  not(A and B), 코드는 not(A or B). A=true/B=None 반례. 따라서 확장해도
  이 후보가 동등해진다고 주장하지 않는다. 원본은 여전히 REFUSED.

`eval/triage_refusals.py`로 **46건 모두 같은 first-refusal 문자열 재현**,
VOID return catalog facts, 원본 후보/manifest/소스 hash 보존 및 위 probe를
기록했다. 첫 실행은 relative __file__ 경로 문제로 산출물 전 실패했고 고친 뒤
완료했다. production 코드는 바꾸지 않아 기존142건을 다시 돌리지 않았다.

근거: `eval/REFUSAL_TRIAGE_V4.md`,
`eval/results/contract_fresh_v4_refusal_triage_2026-09-07_v1.json`,
`eval/results/contract_fresh_v4_refusal_triage_audit/results-audit.{json,md}`.
감사 `internally_consistent_only`, standalone self-review. 분류는 사후 진단이며
원래 실험의 분모/판정을 바꾸지 않는다. 주원인은 한번 집계하고 추가 원인은 겹친다.

실제 TODO: (1) 정답/명세6건 출처와 수정안 검토 — VOID var를 고쳐도 남는 D7
문제를 구분; (2) BOOL any 조건 정규화 설계·nullable/논리 문맥 검사;
(3) 큰 유한/일반 STRING 도메인2건 비용·보장 범위 판단. 생성 코드 문제23건은
생성 파이프라인 항목, 미지원14건은 현 정책 유지. 이후 긴 시간/fixpoint 평가와
남은 formal 근거 보강으로 이어진다. 실제 배포 측정·초록 조기 수정·자동 제출로
되돌아가지 않는다. README 두 곳을 함께 갱신했고 변경은 미커밋이다.

## 최신 인계 — BOOL true/false 전용 계약 구현 완료 (2026-09-07)

**이 절이 최신이다.** 사용자는 formal verification의 의미 보존·완전성 근거
완성이 최우선임을 재확인했다. not-any 문법을 늘리는 대신 기존 명시 비교를
사용할 수 있으며, BOOL에 None이 포함된 것을 지적하고 **true/false만 지원**하도록
지시했다. 모델 ID `strict-two-valued-v1`; RUNTIME_CONTRACT R10과 결정 기록§8에 반영했다.

### 구현과 범위

- `service_model.py`: catalog BOOL/BOOLEAN 센서·조회 반환은 [False, True]
  두 값 모두 열거. BOOL에는 대표값 축약이나 None/0·1 혼합을 하지 않는다.
  명시 domain의 None/잘못된 타입도 거절한다. gate뿐 아니라 두 timed engine이
  같은 service model 검사를 공유한다.
- CatalogRunner는 직접 step/replay에도 필요한 BOOL snapshot이 존재하고
  실제 bool인지 검사한다. missing을 False로 변환하지 않는다. 필요한 BOOL key는
  adapter에서 한번 계산해 보관한다. 논리 상태의 메모 key를 바꾸지 않는다.
- clock.isholiday는 BOOL 도메인으로 처리하고 명시 None/0·1을 거절한다.
  비BOOL 결측과 타입 미선언 synthetic/GV 초기 도메인, 미초기화 로컬 변수의
  None은 일괄 제거하지 않는다. BOOL 비교 상수가 있다는 것만으로 untyped 입력을
  BOOL로 추측해 다른 허용값을 누락하지 않는다.
- 입력이 계약 밖이면 REFUSED. 이 모델은 처음부터 유효한 BOOL을 제공한다는
  규범적 가정이며 실제 장치 측정 사실이 아니다. D7/IR schema/binding/시간 계약은 유지.
- 두 모션센서의 네 true/false 조합에서 `all(Motion == false)`와
  `not(any(Motion == true))`를 양쪽 adapter로 대조하고 bounded 동등 판정 확인.
  `not(all(Motion == true))`는 여전히 다르다. 맨 not-any frontend 확장은 하지 않았다.

### 검사 및 결과

- 기존121 + service model25 = **146개 전체 회귀 통과**. 새4개는 BOOL
  sensor/property, BOOL query 반환, 명시/direct engine/direct replay 거절,
  두 센서 quantifier 동치, BOOLEAN alias/holiday/비BOOL 결측 보존을 검사한다.
  테스트 orchestration 최초에는 mapping 모듈 이름을 잘못 지정해 실행이 실패했고
  실제 `test_mapping_response` 3개로 정정해 통과했다. 테스트 실패를 숨긴 재시도가 아니다.
- 독립 kernel **563 paired histories / 1,126 trace 대조**, IR-only cycle1,
  실행기 변이2개 검출, 실패0. BOOL 프로그램10개는 2⁵, STRING 조회1개는 3⁵.
  과거 2,673을 현재 결과라고 재사용하지 않는다.
- 손 trace14 PASS/기대 REFUSED1/프로그램 변이3 검출. Catalog 개발8개 기대
  결과 일치(기대 거절2 포함). 전부 새 파일이며 기존 결과는 유지했다.
- 새 결과: `eval/results/e1_internal_semantics_bool2_2026-09-07_v1.json`,
  `e1_target_bool2_2026-09-07_v1.json`,
  `contract_v1_service_catalog_bool2_2026-09-07_v1.json`.
- 새 production evaluator SHA:
  `2035063a9033176a7a669dff385354fb04e307c2fc11a533369a96a1f1574776`.
  catalog SHA는 이전과 동일. README·계약·입력/실행기 근거·지원 범위를 동기화했다.

### 다음 작업과 보존

formal 논증의 전제 충족을 우선 점검한다. 참조IR/catalog6건 검토, 입력 모델
한계2건 판단, 더 긴 시간/가능한 fixpoint 평가가 남는다. BOOL None 때문에
맨 any 문법 확장을 필수로 주장하지 않는다. 거절14건 산술/반환 정책은 유지한다.
fresh-v4/거절46건 분류는 이전 nullable BOOL 모델의 역사적 결과다. 소급 판정을
바꾸거나 현 모델의 새 held-out 성능으로 재사용하지 않는다. 재평가 시 새 manifest를
만든다. 사용자 후보·dataset·catalog·초록·등록/제출은 변경하지 않았고 미커밋이다.

## 최신 인계 — formal 증명 의무 O1–O6 검토·보완 (2026-09-07)

**이 절이 최신이다.** 사용자 TODO 1: 입력 이산화, BFS 이력 포괄성, 상태 병합과
시간 점프를 증명 및 구현에 대응하라는 작업을 수행했다. 핵심 문서는
[PROOF_OBLIGATIONS.md](PROOF_OBLIGATIONS.md)이다. O1 입력 대표, O2 출처/전이
보존, O3 결정론성/무행동 구간, O4 상태 키, O5 BFS 귀납, O6 cap/판정 및 별도
fixpoint 시간 이동을 정리했다. 정의한 모델의 bounded 정리의 수작업 증명과 코드
검토이며, 전체 지원 Python 구현의 기계 검증 또는 테스트 완전성을 선언하지 않는다.

### 실제 오류 발견과 수정

DOUBLE은 int 1과 float 1.0을 모두 허용하지만 자동 exact 도메인은 float만
생성했다. IR이 밝기 x==1일 때 Speak("value=$x"), 코드가 Speak("value=1.0")이면
자동 경로 EQUIV-BOUNDED, 명시 [1] 경로 DIVERGE가 재현됐다. 조건 분할의 문제가
아니라 관찰 원값 전수 열거의 타입 누락이다. `ServiceModel.representatives`의
DOUBLE exact 경로에 범위 내 모든 int 표현을 추가하여 자동 경로에서도 재생 확인된
DIVERGE를 얻었다. BOOL/비BOOL 결측/시간/binding/D7 계약은 유지했다.

### 확인된 근거

- 기존146 + service2 + search5 = **153개 전체 회귀 통과**(8 suites).
- 새 `tests/test_search_correctness.py`: 메모 없는 매 ms 재시작으로 9 program
  pairs×4⁴=2,304개 이력 검사. 초기 GV 포함 16+32=48개 별도 이력도 대조.
  모든 BFS 판정 일치, 반례 재생 확인. 이 대조는 파서/실행기/관찰을 공유하므로
  독립 E1을 대신하지 않는다.
- delay/period/wait/sustain/timeout/edge/clock 생략 ms의 ACTION 없음·상태 동일,
  호출자 저장소 비변경, 큰 시간 이동의 저장소/만료 대응, 3종 자원 cap 검사.
- 현재 소스로 독립 E1 **563 paired histories, 1,126 trace 대조**, IR-only cycle1,
  실행기 변이2개 검출, 실패0. 전체 프로그램 공간의 전수조사라는 뜻은 아니다.
- 결과: `eval/results/proof_obligations_2026-09-07_v1.json`(현재 소스 hash와
  8 suite 원시 출력), `eval/results/e1_internal_semantics_proof_2026-09-07_v1.json`.
  py_compile 및 git diff --check 통과.
- 현재 evaluator SHA:
  `0f37f3a37120daf20c3abd2190c3ba6a95acdbc8f99812862fffa4425beda33f`.
  위 두 새 결과에 기록한 소스 hash는 현재 파일과 모두 일치한다.

### 다음 작업

1. 정답 IR/catalog 불일치6건 검토. 잘못된 VOID 반환 대입/필수 인자 등 교정안.
2. 입력 한계2건(큰 numeric, 관찰되는 임의 STRING)의 지원 비용/범위 판단.
3. 현재 DOUBLE/BOOL 모델과 소스를 동결한 재평가 및 긴 시간 범위 평가.
   fixpoint의 보장은 실제 그래프가 닫힌 경우만; 무제한 그래프의 유한성은 미증명이다.

formal 의미 보존/포괄성은 계속 우선 기준이다. bare not-any 확장이나 D7 재개는
필수가 아니다. 과거 fresh-v4/triage/E1 결과는 역사적 소스로 보존한다. 사용자
후보·dataset·catalog·초록·등록/제출은 변경하지 않았으며 변경은 미커밋이다.

### Compact 재개 지점 — 다음 작업의 구체 범위 (2026-09-07)

사용자가 다음 작업을 물으며 compact 전 기록을 요청했다. 이 시점에는 아래
6건의 후속 분석을 시작하지 않았고, 직전 O1–O6 검토/DOUBLE 수정은 완료했다.
재개 시 완료한 153개 회귀나 563이력 E1부터 불필요하게 반복하지 않는다.

**바로 다음: 정답 IR와 서비스 명세 불일치 6건의 출처 확인 및 교정안 작성.**
목적은 검증기가 비교하는 기준 자체의 신뢰성을 확보하는 것이다. 모든 거절을
통과시키거나 Gemma 오류로 처리하는 작업이 아니다.

| ID | 시작할 확인 지점 |
| --- | --- |
| C01_006 | VOID Television.SetChannel의 `var: Television.Channel`; 산술 인자도 남음 |
| C01_017 | VOID Speaker.Speak의 `var: TodayMenu` |
| C14_001 | VOID Light.MoveToBrightness의 `var: Light`; 산술/period 차이 |
| C14_005 | VOID Light.MoveToBrightness의 `var: Light`; 산술/selector/service |
| C14_006 | VOID LevelControl.MoveToLevel의 `var: LevelControl.CurrentLevel`; 산술 |
| C03_002 | IsAvailable의 필수 ServiceName 누락; 설명은 이름인데 타입 BOOL, 다중 기기 반환도 확인 |

진행 순서:
1. `eval/REFUSAL_TRIAGE_V4.md` §2와
   `eval/results/contract_fresh_v4_refusal_triage_2026-09-07_v1.json`에서 해당 행의
   원본 IR·binding·후보·첫 차단과 추가 차단을 확인한다.
2. `eval/results/contract_fresh_v4_2026-09-07_manifest.json` 및 기록된
   candidate_path로 원본 task/정답 출처까지 추적하고
   `../files/service_list_ver2.0.7.json`의 실제 정의와 대조한다.
3. 각 행에 원래 의도, 불일치 원인, 근거, 최소 교정안, 교정 뒤에도 남는
   미지원/후보 오류를 구분해 기록한다. 복사 fixture에서 준비/탐색 결과를 확인한다.
   원래 의도를 근거 없이 추정해 인자를 채우거나 `var`를 일괄 삭제하지 않는다.
4. 변경안을 검토 가능한 형태로 정리한다. 원본 dataset/catalog와 과거 평가를
   소급 수정하지 않는다. 명세를 바꿀 경우 읽기 역할 인증이 catalog SHA에
   고정되어 있으므로 영향 범위도 설명한다.

그다음: 입력 한계2건 C01_009(큰 유한 DOUBLE), C01_018(관찰되는 일반 STRING)
판단 → 현재 소스/입력 모델 동결 후 재평가·긴 시간 범위 평가.
과거 fresh-v4는 익숙한 388문제의 새 생성이며 정상329개 중308개 코드가 v3와
같았다. 엄밀한 미노출 held-out으로 부르거나 무작정 새 생성부터 반복하지 않는다.

항상 유지: formal 의미 보존/포괄성 우선, BOOL true/false, DOUBLE exact의
int/float/signed-zero 보존, 고정 binding, 입력100ms/정확 timer1ms, D7 거절.
bare not-any 지원 확대와 실제 장치 측정은 필수가 아니다. 초록의
`formally verifies`는 11일까지 보완해 본 뒤 판단한다. 사용자는 아직 미등록이고
등록도 11일까지라는 계획이다. 이번 compact 기록에서는 코드/평가를 바꾸지 않았다.

### 정답 IR/catalog6건 원인 분석 완료 (2026-09-07)

사용자 요청: “명세 불일치 6건 원인 분석 및 보고”.
[상세 보고서](eval/REFERENCE_CATALOG_ANALYSIS.md) 및
`eval/results/reference_catalog_analysis_2026-09-07_v1.json`에 출처·원본 행·
카탈로그 facts·Git snapshot·SHA·최소 IR patch 제안·복사본 진단을 저장했다.

- 5건 VOID 대입은 `d886015:dataset.csv`부터 있으며 당시 v2.0.4도 VOID.
  최신 명세 변경이나 fresh Gemma의 IR 생성으로 생긴 문제가 아니다.
- C03_002는 `c264425`에서 함수의 값 읽기를 args={} 호출로 교정했다.
  당시 percom §9.2는 “기본값 규약으로 허용”이라고 썼지만 실제 인자
  ServiceName에는 default/optional이 없고 설명=name/type=BOOL 모순도
  v2.0.4부터 존재한다. 현재 두 provider 반환의 scalar 집계 문제도 확인했다.
- 이전 감사는 반환형/필수 인자 누락을 검사하지 않았다. 현재 상위
  validate_ir_against_catalog도 같은 검사 공백이 있어 후속 재발 방지 대상.
- 원본6건의 첫 REFUSED 모두 재현. 해당 call.var만 지운5개 복사본은 준비
  통과. 그 뒤 D7 산술4건, C01_017 observable STRING1건으로 계속 REFUSED.
  C01_017을 기존 C01_018과 같은 입력 모델 문제로 후속 검토에 포함한다.
- C14_005 LevelControl selector/Light 서비스는 Bedroom_Light가 양쪽
  capability를 가져 적법하다. 이전 의심은 해소. C14 세 행 모두 IR100ms/
  code1000ms 차이가 남지만 이번 작업에서 DIVERGE 라벨을 붙인 것은 아니다.
- C01_006은 Channel=0에서 -1이 함수 범위를 벗어나는 추가 경계 문제.
  ChannelDown 대안은 ACTION 자체가 바뀌므로 무단 동치 치환 금지.
- C03_002의 true 인자 복사본은 다음 다중 반환 거절 확인용일 뿐, 서비스
  이름/실제 교정안이 아니다. API 의미/대상/집계는 아직 결정하지 않았다.

원본 dataset/catalog/후보/production/과거 결과는 SHA로 불변 확인했다.
새 분석 자료와 문서만 작성했고 전체153회귀/E1은 코드 변경 없어 재실행하지 않았다.
다음: 5개 최소 교정 제안 반영 및 상위 validator 재발 방지, C03_002 계약 정리,
입력 한계(C01_009/C01_018 및 동일 유형 C01_017) 검토 후 새 동결 평가.
이번 사용자 요청은 분석/보고였으므로 원본 교정은 아직 적용하지 않았다.

### cloud-availability-v1 및 reference 교정 반영 완료 (2026-09-07)

사용자 확정: “네 추천대로 해. 그냥 사용 가능한지 bool.” 직전 추천의
무인자 BOOL 조회 및 Main 확인→Main 업로드 정책을 반영했다.

- `files/service_list_ver2.0.7.json`: IsAvailable의 ServiceName 제거,
  선택된 provider의 사용 가능 여부라는 descriptor, BOOL true/false 반환.
  현재 SHA `e69e5e442441197ff7d8eece70ad59fe966d82469fb07fc9dfc57c2446c4df9c`.
  전체 구조 대조로 이 함수의 descriptor/arguments만 변경됨을 확인하고
  `service_model.REVIEWED_CATALOG_SHA256`를 재인증했다. 나머지6개 읽기 함수 동일.
- dataset C03_002: 한/영 NL에서 Main을 명시, binding을 Main 한 대로 교정.
  Backup은 inventory에 그대로. IR 호출은 기존 args={} / var=IsAvailable 유지.
- VOID 반환 대입5건 제거. 상위 전388행 검사에서 C14_007의 동일 결함을
  추가 발견해 제거했다. 이 행은 과거 GENERATION_ERROR라 원래6건 분석 밖이었다.
  총7행만 변경, C03_002 외6행은 ir_gt의 불필요 call.var만 제거했다.
- `timeline_ir.catalog.load_catalog`에 return_types 보존, 상위
  `validate_ir_against_catalog`에 missing_required_arg/void_return_assignment 추가.
  기존 functions 인자 목록 인터페이스 유지. cloud hint와 extractor R-var도 보완.
- 수작업 참조 코드 `eval/fixtures/cloud_available_main_v1.json`은
  EQUIV-BOUNDED(3200ms). Backup을 inventory 첫 순서로 놓아도 Main 선택,
  false→무행동/true→Main 업로드, None 거절, Backup 업로드 변이 confirmed DIVERGE.
  **생성 모델의 새 성공 사례가 아니다.** 과거 fresh-v4 C03_002는 any 함수
  반환 대입 때문에 현재 교정 reference와도 REFUSED다. 후보 수정/새 생성 없음.
- 나머지 원래5건도 산술4/일반 STRING1로 계속 REFUSED. C14_007도 산술
  지원 확대 없이 reference만 교정. 이전 집계/원시 결과는 소급 수정하지 않는다.

검증: 상위 이름/서명/VOID 검사 정답388/388 통과(동등성 검사가 아님),
9모듈159회귀 통과(새6개 포함), 독립 E1 563 paired histories/IR-only1/실행기 변이2개
검출/실패0. 최초 새 테스트에서 ACTION target을 문자열로 기대했지만 실제
단일 장치 그룹 표현은 tuple이라 기대값을 정정했고 최종159개 모두 통과했다.

근거: `eval/results/reference_catalog_repair_2026-09-07_v1.json`(변경 전후7행,
source SHA, 159테스트 raw 출력, cloud 참조/변이 판정, 과거후보 불변 확인),
`eval/results/e1_internal_semantics_cloud_v1_2026-09-07.json`.
이전 proof/fresh-v4/analysis artifact는 당시 source/catalog를 담은 역사적 자료다.
실제 허브/기기 런타임 배포는 수행하지 않았다. 선언 명세+IR/JoI 실행 모델 작업이다.

**바로 다음:** 입력 모델 한계 검토 — C01_009 큰 유한 DOUBLE,
C01_018 및 C01_017 일반 STRING. 그 뒤 수정 소스/명세/도메인 동결 평가.
명세6건의 원인 분석/기본 교정을 다시 시작하지 않는다. D7, 고정 binding,
BOOL 두 값, 입력100ms/정확 timer1ms, formal 보장 근거 우선은 유지한다.

### symbolic-value-flow-v1 구현·검증 완료 (2026-09-07)

사용자 요청: C01_009처럼 IR/code 인자의 입력 출처와 타입을 알고 있으니
전수 열거 대신 변수 흐름을 비교하는 계획을 세우고 구현할 것.

- 새 `SYMBOLIC_VALUE_FLOW.md`: 구현 계획과 수작업 보존 증명, 지원 범위.
  `symbolic_values.py`: `(grounded key, input epoch, type, nullable)` 입력 기호와
  None→빈 문자열 변환/문자열 이어붙이기 정규형. 이름만 같다고 인증하지 않는다.
- `symbolic.py`: 기존 IR/JoI runner로 read/대입/문자열/call/fixed delay 실행.
  순차 one-shot이며 clock/GV/분기/wait/주기/산술은 이 경로에서 제외한다.
  입력 epoch를 보존하므로 delay 전 저장 값과 delay 후 fresh read를 구별한다.
  같은100ms 구간은 같은 입력, 100ms 경계 이후는 독립 입력이다.
- ACTION 정규형 일치는 모든 catalog-valued history에 대한 충분조건이다.
  다른 기호 표현만으로 DIVERGE하지 않고, 허용 구체 값을 찾아 기존 재생기로
  확인한다. 반례 미발견/재생 미확인/cap은 UNKNOWN→게이트 REFUSED.
  따라서 witness 후보값을 전체 입력 대표라고 주장하지 않는다.
- `timed_product` 자동 입력 materialization 거절 시 인증 가능한 순차 구조만
  기호 경로를 시도한다. `gate_pair`도 이 진입점을 사용한다. 명시 유한 입력은
  기존 concrete BFS 유지. 기존 D7/BOOL/시간/바인딩 정책 변경 없음.
- `contract_eval` 및 `eval/frozen_contract.py`: 기호 인증/확인 반례를 별도 라벨로
  기록하고 finite exact oracle은 NOT_APPLICABLE. oracle agreement/paired speed
  분모에 넣지 않는다. frozen protocol 입력 설명도 최신 BOOL/기호 규칙으로 보완.

결과: C01_009와 교정 reference의 C01_017은 각각 실행기2회(한 paired step)로
EQUIV-BOUNDED(3200ms). 온도 전체 catalog 범위/표현 및 일반 문자열/None 포함이다.
상수 치환·재대입·기기/member/query args·입력 시점·target/count/order 변이는
구체 반례로 검출. 이름 변경/alias와 같은 input epoch의 재읽기는 정상 인증.

**C01_018은 아직 REFUSED**: 기호 비교와 별개로 raw nullable query 결과가
Speak의 필수 STRING 인자에 도달한다. 명시 None 입력에서도 기존 실행기의
type mismatch로 재현된다. 유한 nonmissing 모델은 그 범위에서만 통과한다.
별도 수작업 fixture에서 양쪽이 문자열로 변환하면 None 포함 보편 인증되지만,
원본 dataset/candidate/catalog를 수정하거나 비BOOL 결측을 임의 제거하지 않았다.

검증: 최종10모듈 **184 tests 통과**(기존159+신규25). 신규에는54개 표현식
valuation의 lift 대응, 81이력×양쪽 실행기=162 history(각3events)의 치환 대응,
100ms 입력/1ms delay, 10^16의 시작 시각, D7·type·cap·재생 거절과 평가 worker
경로가 포함된다. 독립 E1 **563 paired histories/IR-only1/변이2 검출/실패0**.
개발9사례는 SYMBOLIC_CERTIFIED4, DIVERGE_CONFIRMED4, 기대 REFUSED1이다.
증명은 수작업/code correspondence이며 테스트를 보편 증명으로 주장하지 않는다.

근거:
- `eval/contract_v1_symbolic_development.json` — 원본3+개발변이/fixture6; 새 생성 아님.
- `eval/results/symbolic_value_flow_2026-09-07_v1.json` — 기호 인증서/구체 재생.
- `eval/results/symbolic_value_flow_validation_2026-09-07_v1.json` — 184검사 raw 출력/source SHA.
- `eval/results/e1_internal_semantics_symbolic_final_2026-09-07.json` — 최종 source E1.
- 앞선 `e1_internal_semantics_symbolic_v1_2026-09-07.json`은 witness precision
  점검 추가 전 중간 source 기록이며 최종 E1과 구별한다.

**다음:** C01_018 비BOOL 결측/문자열 출력 정책을 정리하고 수정 코드·입력 모델을
동결해 재평가한다. C01_009/C01_017은 해결됐다. 기호 경로의 분기/주기 확장은
현재 필수 작업이 아니며 D7 산술 거절 재개는 합의하지 않았다. 실제 장치 측정,
후보 재생성, commit/push는 수행하지 않았다.

### MenuProvider.GetMenu 반환 정책 확정·구현 (2026-09-07)

사용자: “menuprovider 서비스의 return type은 string이지? 그러면 None은 없는거 처리해.”
`menu-string-return-v1`로 GetMenu 반환을 non-null STRING으로 확정했다. 빈 문자열은
허용한다. 다른 비BOOL 센서/property/query의 None 정책을 일괄 변경하지 않았다.
실제 catalog 반환형 STRING을 확인했으며 nullable 배제는 사용자 승인 목표 계약이다.

- service_model의 return_spec에 nullable=false/근거 기록, 자동·명시 도메인 및
  실행 snapshot/반례 재생에서 None·누락·타입 위반 거절.
- symbolic 입력은 spec의 nullable을 전달하고 non-null STRING의 필수 STRING
  ACTION 전달을 인증한다. 반례 후보도 허용 도메인을 지킨다.
- C01_018 실제 기존 후보가 EQUIV-BOUNDED(3200ms). 정적 출력·다른 조회 인자
  변이는 유효 문자열 반례로 검출한다. 다른 nullable 문자열의 raw 전달 거절 유지.
- 새 manifest `eval/contract_v1_menu_string_development.json`, 결과
  `eval/results/menu_string_return_2026-09-07_v1.json`: 5 SYMBOLIC_CERTIFIED,
  4 DIVERGE_CONFIRMED. 기존 manifest/결과와 dataset/catalog/후보는 수정하지 않았다.
- 10개 모듈 **186개 회귀 검사 통과**. source SHA/raw 출력:
  `eval/results/menu_string_return_validation_2026-09-07_v1.json`.

다음 작업은 현재 코드·모델을 동결하고 **이미 생성한 Gemma4 후보를 재검증**하는
것이다. 388개를 LLM으로 다시 생성하는 작업이 아니며, 새로운 held-out 생성 평가로
주장하지 않는다. 이번 턴에는 전체 388행 재평가를 시작하지 않았다.

### 기존 Gemma4 후보388건 동결 재검증 완료 (2026-09-07)

사용자 “2번 해 그럼”에 따라 기존 fresh-v4 후보를 재사용했다. LLM 호출0회,
후보 SHA 전부 원본 manifest와 일치. 프로토콜·소스 ZIP·388행 manifest를 먼저
동결하고 각 준비 성공 건에 Explorer/exact 각1회 실행했다. 자원·시간 범위는
이전과 같은 H3200ms/입력100ms/타이머1ms, 200k상태/500k전이/100k입력조합,
엔진당20초/768MiB. 현재 선언에는 strict BOOL, non-null GetMenu,
앞서 승인한 catalog/reference 교정과 symbolic-value-flow-v1을 포함한다.

- 동등207(이전203), 불일치76(77), 거절43(46), 미완료1, 기존 생성 실패59,
  준비 오류2. 총388건, 실행171.05초. 모든 불일치 구체 반례 재생 확인.
- C01_009/C01_017/C01_018 거절→동등. C21_001 불일치→동등은 BOOL None 배제:
  이전 L=true/B=None 반례는 모델 밖이며 현재4개 Boolean조합에서 동등.
  나머지384건의 Explorer 최종 판정은 그대로다.
- 두 유한 탐색 공동 완료267건 전부 일치. 기호 인증3건은 exact NOT_APPLICABLE로
  별도 집계. exact INCOMPLETE14건 중 Explorer는12동등/1불일치/1미완료.
- C01_014는 입력 조합 상한으로 INCONCLUSIVE. 준비 오류2건은 기존 후보의
  문법 문제(C24_004, C26_006). 거절은 의도적 미지원과 생성 계약 위반 등이 혼재.
- 과거 결과/후보/데이터는 이번 턴에 수정하지 않았다. 신규 reporter만 추가했고
  실제 검증 구현은 수정하지 않았다. 실행 전후 source/candidate SHA 일치, ZIP
  내용 digest 검사 완료. 현재 README/작업현황의 사후 변경은 ZIP에 든 동결본과 구별한다.

파일 접두사 `eval/results/contract_recheck_v4_2026-09-07_v1`:
`_protocol.json`, `_sources.zip`, `_manifest.json`, `_evaluation.log`,
디렉터리 내 `case_outcomes.jsonl`, `summary.json`, `metrics.json`, `report.md`,
`change_analysis.json`, `change_analysis.md`; `_audit/results-audit.json/md`.
재현 reporter는 `eval/report_recheck.py`. 자체 감사는 exploratory이며 구조 검사 통과.
최초 사후 reporter의 ZIP 절대경로 조회 실패는 leading slash 정규화로 수정했다.
평가 자체는 재실행하지 않았고 실패 이력은 audit에 기록했다.

**다음:** C01_014 입력 조합 상한 처리 검토 → 이 결과와 지원 범위/증명 근거를
논문의 bounded formal verification 설명에 연결. 이 재평가는 outcome-visible
개발 결과이며 새로운 held-out이나 단독 ablation으로 주장하지 않는다.
D7 거절 재개, 실제 장치 측정, 새로운 후보 생성, commit/push는 하지 않았다.

### C01_014 자동 입력 cap 기호 인증 및 전체 재검증 v2 (2026-09-07)

사용자 “맞아. 출처만 같으면 되니까. 진행”에 따라 입력 cap fallback을 연결했다.
출처만으로 무조건 통과시키지 않고 기존 source/epoch/변환/ACTION/시간 증명 전제를
유지한다. timed_product는 입력이 자동인지 기억하고, 입력 조합/초기 전이 cap에
걸리면 기존 symbolic_product를 시도한다. 명시 domain/초기 GV는 기존 범위를 유지.
부적격 프로그램/기호 예산 고갈/미확인 반례는 인증하지 않는다.

- symbolic_input_cap_fallback 선택 함수를 개발 evaluator/frozen 준비에도 연결.
  C01_014 자동 domain110,004개 > cap100,000개. 실제 시나리오를 값마다 실행하지
  않고 기호 paired step1회(IR+code2회)로 동등 인증. 유한 입력 목록 구성 비용은
  현재 남아 있지만 전체 값별 실행은 피한다. 서비스 명세·정답·후보 변경 없음.
- 새8검사와 기존186검사 모두 통과(194). 정적값/100ms뒤 새 읽기 변이는 재생
  확인 DIVERGE. 명시 domain cap은 미완료 유지. 분기/기호 전이 cap 검사 포함.
- 개발12케이스: SYMBOLIC_CERTIFIED6, DIVERGE_CONFIRMED6.
  `eval/contract_v1_input_cap_development.json`,
  `eval/results/symbolic_input_cap_2026-09-07_v1.json`,
  `eval/results/symbolic_input_cap_validation_2026-09-07_v1.json`에 SHA/raw 기록.
- 전체388건 새 동결 실행 `eval/results/contract_recheck_v4_2026-09-07_v2`:
  동등208, 불일치76, 거절43, Explorer미완료0, 기존 생성 실패59, 준비 오류2.
  약170.65초, LLM0회. 직전v1 대비 C01_014만 INCONCLUSIVE→EQUIV-BOUNDED.
  나머지387건 동일. payload/후보/도메인 계약은 같고 검증 전략 선택만 변경됐다.
- finite 공동 완료267건 전부일치; 기호4건은 exact NOT_APPLICABLE.
  exact INCOMPLETE13건은 Explorer가12동등/1불일치로 판정했다. Explorer의 미완료0을
  exact미완료0이나 전388건동등으로 표현하면 안 된다. 모든 불일치 재생 확인.
- `_protocol.json`, `_sources.zip`, `_manifest.json`, `_evaluation.log`,
  디렉터리 내 `case_outcomes.jsonl`, `summary.json`, `metrics.json`, `report.md`,
  `_audit/results-audit.json/md` 기록. 실행 전후 SHA일치와 ZIP 내용 검증.
  실행 후 reporter의 버전별 audit ID와 비교 설명을 일반화했고, 보고서 source SHA는
  audit에 별도 기록했다. 실행 중 source 수정은 없고 동결 ZIP은 보존했다.

다음은 논문에 지원 조각·입력 도메인·H=3200ms bounded 주장·수작업 증명/실행기
대응·현재 동결 평가 수치를 연결하는 작업이다. C01_014 cap TODO는 완료됐다.
D7 재개·실제 장치 측정·새 후보 생성·commit/push는 하지 않았다.

### 후속 사용자 승인: SMT 선형 산술 ACTION trace 검증 (2026-09-07)

이 항목이 위 D7 무조건 거절 기록보다 최신이다. 사용자는 joint guard/산술 ACTION을
SMT로 확장하는 구현을 승인했고, float 문자열 정규화는 불필요하다고 결정했다.

- `smt.py`, `smt_values.py`, optional `requirements.txt` 추가. 자동 catalog 숫자
  one-shot, 명시 H, acyclic IR/code에서 선형 산술·조건·ACTION·고정 delay/wait 지원.
  기존 실행기와 정확한 deadline 스케줄러를 사용하고, 값은 기호로 유지한다.
- 분기 시 양쪽 경로를 조건과 함께 유지한다. 실행 불가능한 경로를 포함한 과대근사를
  허용하고, 실제 ACTION 차이 질의에서 전체 조건을 검사한다. 같은 표현이면 solver
  호출을 생략한다. typed store/time/path가 완전히 같은 경우만 병합한다.
- Z3 정수·IEEE binary64 연산으로 0.1 격자/int 표현/signed zero/None과 실제 연산
  순서를 보존한다. 정수 문자열은 정확히, float 문자열은 공유 미해석 함수로 다룬다.
  UNSAT은 안전한 충분조건, SAT은 반드시 구체 ACTION 반례로 재생한다.
- query 1초/SMT 작업10초/query10000 기본 caps. 시간 초과는 UNKNOWN이다.
  시간 초과 뒤 기존 작은 진단 입력으로 반례를 찾을 수 있으나, 샘플로 EQUIV를
  판정하지 않는다. 미해석 문자열의 SAT가 재생되지 않아도 UNKNOWN이다.
- 숫자 ACTION type/range 포함을 전칭 검사한다. C01_006(기존 후보)은 SMT 조건을
  만족하지만 채널 최솟값에서 Channel-1이 인자 범위를 벗어나 REFUSED 유지.
  전체 후보에 대한 준비/eligibility 확인에서 새 SMT에 진입 가능한 것은 이1건이었다.
  이는 전체388건의 새 실행/평가가 아니다.
- `timed_product`, 개발 evaluator, frozen prepare/worker에 연결. exact 유한 열거기는
  자동 SMT 도메인에서 NOT_APPLICABLE로 표시한다. 명시 input domain/초기 GV는
  전체 catalog 기호 도메인으로 승격하지 않는다. 기존 D7 검사는 기존 엔진에 유지.
- 현재 조각 밖: periodic/loop/cycle/GV/clock, 입력끼리 곱셈, 동적 제수, modulo,
  비숫자 입력 혼합 및 bound 없는 입력 등. JoI 파서에 abs builtin을 새로 추가하지 않았다.
  IR abs는 지원한다. 모든 산술 또는 모든 프로그램 지원으로 표현하지 않는다.

검증과 파일:

- 기존194 + 새29 = **223개 회귀 통과**. 새 검사는3센서 평균, 결합 조건, 반례,
  정수 UNSAT 질의 재검사, 인자 범위, 실수 대수로 잘못 단순화하면 놓치는 float 차이,
  epoch/delay/wait/마감 경계/D1/caps/frozen worker를 포함한다.
  산술405조합·비교486조합에서 양쪽 실행기와 기호 실행의 대응 확인.
- `eval/contract_v1_smt_development_v2.json`와
  `eval/results/smt_trace_2026-09-07_v2.json`: 개발20건 **기호 인증5 / 재생 불일치8 /
  예상 거절7**. 실제 서비스 snapshot 기반 fixture이며 held-out 평가가 아니다.
- `eval/results/smt_trace_validation_2026-09-07_v2.json`: 최종 회귀 raw 결과/소스 SHA.
- `eval/results/e1_internal_semantics_smt_2026-09-07_v2.json`: 독립 E1 **563 paired
  histories + IR-only1 / 실제 실행기 변이2개 검출 / 실패0**. E1은 제한된 내부 의미론
  kernel 확인이며 SMT 전체에 대한 독립 proof oracle로 표현하지 않는다.
- [SMT_VERIFICATION.md](SMT_VERIFICATION.md): 정확한 명제, 지원 조건, 수작업
  증명 의무/구현 대응, float 문자열 과대근사·비용·한계. README들과 입력/서비스/
  supported-fragment/proof 문서에도 최신 상태를 연결했다.

**최종 자체 검토 교정:** 초기 개발 버전에서 텍스트 조건식이 객체 identity equality로
False가 되거나, symbolic BOOL의 뺄셈이 IR TypeError 처리로 None이 되는 false-EQUIV
2건을 발견했다. 실제 입력1에서 exact 실행 ACTION 차이를 확인했다. `SmtValue`가
미구현 연산을 반드시 Unsupported로 거절하게 고쳐 두 경우를 REFUSED로 고정했다.
v1 테스트/개발/E1 기록은 교정 전 이력으로 보존하고, 최종 증거는 위 v2를 사용한다.
문자열 guard와 symbolic BOOL 산술은 이번 지원 범위에 추가하지 않았다.

**다음 TODO:** 새 SMT 버전을 동결한 기존388개 후보 재검증(LLM 생성 불필요) 후,
논문의 (1) 정확한 보장 명제, (2) BFS/기호/SMT 증명 근거, (3) 평가 수치·H=3.2초·
지원 제한을 연결한다. 기존 v2의208동등/76불일치/43거절/0미완료/59생성실패/2준비오류는
그 소스 버전의 역사적 결과다. 이번 구현 버전의 수치로 재사용하지 않는다.
실제 기기 측정, IR/catalog/dataset 변경, LLM 호출, commit/push는 없었다.

### SMT 버전 기존388건 전체 재검증 v3 완료 (2026-09-07)

위 마지막 TODO 중 전체 재검증은 완료했다. 결과 prefix는
`eval/results/contract_recheck_v4_2026-09-07_v3`이며 protocol/manifest/source ZIP,
원시 case_outcomes/summary, metrics/report/change_analysis, followup_verification,
`_audit/results-audit.json/md`를 보존했다. 이전 v2가 명시적 비교 부모다.

- LLM 호출0회, 모든 기존388개 ID 포함, 후보 SHA/IR/binding/기기/catalog 유지.
  H3200ms/입력100ms/타이머1ms와 기존 자원 제한 유지. 새 SMT caps는 실행 전 동결.
  한 번씩 전건 실행해 **175.859631초**, 과학적 재시도 없음.
- **동등208 / 재생 불일치76 / 거절43 / Explorer 미완료0 / 생성 실패59 / 준비 오류2**.
  직전 v2 대비 최종 판정 변경0건. 공동 완료 유한267건은 모두 같은 판정이며
  기호 인증4건(C009/C014/C017/C018)은 기존 value-flow 경로, 별도 분모다.
- C01_006만 준비 REFUSED→SMT READY→실행 REFUSED로 단계/이유가 바뀌었다.
  현재 채널0에서 IR/code 모두 SetChannel(-1); 입력과 인자 범위는0..10000이므로
  서비스 인자 계약 위반이다. ACTION trace 불일치를 뜻하지 않는다.
  준비 거절42 + 실행 거절1 = 최종 거절43. 신규 SMT corpus 인증0건.
- exact 미완료13건(Explorer12동등/1불일치)은 이전과 같다. NOT_COMPARABLE14는
  이13건 + SMT 거절1건이다. exact NOT_APPLICABLE5는 인증4 + SMT 거절1건이다.
- 실행 전후 source/candidate SHA, archived ZIP 바이트, 모든76개 반례의 재생을 확인.
  최종223개 회귀 근거와 동결 평가의 코드/requirements 교집합64개 SHA 모두 일치.
  이번에는 회귀/E1을 다시 실행하지 않았다. 새 corpus와 개발20케이스를 합산하지 않는다.
- 자체 감사 `E3-CONTRACT-RECHECK-V4-V3`, `supports_exploratory_follow_up`.
  구조 validator 통과는 과학적/독립 검증을 뜻하지 않는다. 원시 판정 일치는
  전체 언어/SMT 구현의 무오류 증명이나 unseen held-out/성능 향상 근거가 아니다.
- 평가 reporter는 실행 전에 기호 경로/거절 단계 표시와 부모 lineage 설명을 보완해
  동결했다. 완료 후 README/본 인계/SMT 문서만 최신 결과로 갱신했다. 평가 소스 ZIP은
  그대로 두며 문서의 후속 변경을 실행 중 source 변경으로 오해하지 않는다.

**다음 TODO:** (1) 지원하는 IR–code 쌍과 합의한 입력·시간·binding 모델에서의 정확한
bounded ACTION trace 동등성 명제, (2) BFS/상태 병합/입력 이산화/기호 비교/SMT의
증명 의무와 구현·검사 근거 대응, (3) 최신388건 결과/H3.2초/지원 및 거절 조건을
논문 설명으로 연결한다. 이번 단계에서 abstract/IR/catalog/dataset는 수정하지 않았다.

### 출력 변수 관계와 fixpoint — 구현 계획 작성 (2026-09-08)

사용자는 변수 갱신도 내부 비교 대상으로 두고, 출처·초기화·갱신·조건·시간이
일치하는 경우에만 보수적으로 인증하자고 제안했다. 증가 count의 값을 계속
열거하지 않고 양쪽 값의 동일 관계를 보존하는 새 경로를 계획했다.
[RELATIONAL_FIXPOINT_PLAN.md](RELATIONAL_FIXPOINT_PLAN.md)가 상세 계획의 원본이다.

- **상태: 계획 완료/구현 미착수.** 코드·후보·IR 명세·catalog·기존 평가 결과는 그대로다.
- 기존 SMT를 제거하지 않는다. 관계 초기화/모든 전이/출력 동등성 및 유한 관계
  그래프 폐쇄를 확인한 경우에만 H 없는 EQUIV-FIXPOINT를 반환할 계획이다.
- R0: 출력에만 쓰는 IR 이름 카운터의 증가 제거 문제를 먼저 수정한다.
  직접 IrRunner 재현에서 t=0,1000ms의 `count: 0` 반복을 확인했다.
  기존 gate의 허위 인증이 확인된 것은 아니다. modulo 원값 유출도 함께 점검한다.
- R1/R2: 변수 대응·타입 보존 기호·ACTION/갱신 순서와 후속 관계 검사.
- R3/R4: 단일 cycle의 관계 BFS와 시간 이동/폐쇄, 이어서 동일 기호 조건의 양 분기.
- R5: 제한된 새 경로만 gate/평가에 연결. 구조 불일치는 자동 DIVERGE가 아니며
  재생 확인 반례 또는 미완료/거절로 처리한다. 무제한 정수 문자열 변환도 확인한다.
- 처음에는 단일 INTEGER 카운터 출력으로 시작하고 입력·delay·wait를 연결한다.
  float 반복 관계·GV·중첩 cycle·변수 시간은 이번 첫 경로의 범위 밖이다.
- 완료 후 회귀/E1/기존388 재검증 및 별도 무제한 평가. 현재208개 bounded 인증을
  무제한 성공으로 재분류하지 않는다. 새 LLM 생성은 필요하지 않다.

### 관계 기반 무제한 검증 1차 구현·검증 완료 (2026-09-08)

**현재 인계 기준은 이 절과 RELATIONAL_FIXPOINT.md다. 위 구현 미착수는 이전 단계 기록이다.**

- 사용자가 R0–R5 구현을 승인했고 완료했다. 새 파일은 `relational_analysis.py`,
  `relational_values.py`, `relational.py`, `integer_text.py`, 신규28개 테스트 및 개발 manifest다.
- IR 출력 카운터 증가 제거/modulo 원값 축약을 수정했다. 기존 unsupported/D7는 유지한다.
- 선택한 카운터 초기화/갱신과 ACTION 사이 순서를 실제 실행기에서 내부 기록한다.
  타입·연산 AST·문자열 변환·ACTION/갱신 post 관계를 검사한 뒤에만 N으로 일반화한다.
- 기호 비교의 Python identity/default 동작을 막고, 미구현 연산을 명시적으로 거절한다.
  입력은 직접 guard 전용 공동 분할 전체 곱집합, 정수 조건은 모든 기호 분기를 전개한다.
- clock 없는 실행에서 정확한 타이머 age와 입력 phase를 키에 보존한다. 살아 있는 snapshot은
  현재 카운터와 동일시하지 않는다. 보수적 entry liveness로 period 경계의 dead copy만 제거한다.
- `timed_product`/`gate_pair`에서 `verification_mode='relational', horizon_ms=None`으로 선택한다.
  기존 자동 경로는 유지한다. H를 지정하면 새 경로는 거절하며 bounded를 승격하지 않는다.
  성공은 초기 관계/모든 전이/그래프 폐쇄 완료를 필요로 하고 cap은 UNKNOWN이다.
- 새 경로의 DIVERGE는 최초 구체 반응의 불일치와 재생에 한정된다. 추상 관계/관찰 실패는
  미완료/거절이며 구체 반례라고 주장하지 않는다. 일반 invariant/IC3는 구현하지 않았다.
- 첫 지원 구조: 단일 최상위 이름 카운터 cycle, 동일 양의 period, JoI 첫 INTEGER :=,
  정수 +/−/복사/명시적 문자열 출력, if/wait/delay. cycle until, 중첩 cycle, GV, query,
  modulo, 관계 float, 동적 시간, 복잡한 live snapshot은 계속 지원 밖이다.
- 무제한 INTEGER 십진 변환은 9자리 chunk로 구현하여 Python의 문자열 자릿수 제한을
  인증 전제로 넣지 않는다. 실제 JoI 구현의 INTEGER 모델 적합성은 선언한 계약의 전제다.

검증·평가 결과:

- `relational_validation_2026-09-08_v1.json`: **251개**(기존223+신규28) 전부 통과.
  초기 테스트 기대값에 두 스피커 중복 횟수와 숫자 대표값 수를 잘못 쓴 부분은 교정했고
  최종 검사는 D1의 중복 보존과 guard 포괄성을 확인한다. 실패 이력은 감사에 기록했다.
- `relational_development_2026-09-08_v1.json`: 개발20건 **EQUIV-FIXPOINT6 / 재생 불일치3 /
  INCONCLUSIVE8 / 구조 거절3**, 사전 지정 기대 판정과 모두 일치. 단순 count 반복은10상태.
- `e1_internal_semantics_relational_2026-09-08_v1.json`:11프로그램/563이력/IR별도1이력/
  실행기 변이2검출/실패0. 제한된 E1이며 관계 증명 자체의 독립 oracle이 아니다.
- `contract_recheck_v4_2026-09-08_v4`: LLM0회, 약183초, 기존388 전건:
  **동등208 / 재생 불일치76 / 거절43 / Explorer 미완료0 / 기존 생성 실패59 / 준비 오류2**.
  이전 v3와 최종 판정 전부 동일. 유한 공동 완료267건 일치, 기호 인증4건은 별도.
- `relational_corpus_2026-09-08_v1`: 같은388 전건에 H 없는 경로의 준비/지원 검사:
  **거절327 / 기존 생성 실패59 / 준비 오류2, 진입0/신규 무제한 corpus 인증0**.
  개발6건을 corpus 무제한 인증 수에 넣지 않는다. summary의 run wall은 준비 시간이 아니다.
- 두 protocol/manifest/outcome/source ZIP 및 기존 후보 SHA 확인. 회귀/E1의 Python SHA와
  평가 코드가 같다. 원시 결과를 재작성하거나 후보를 재생성하지 않았다.
- 구 report helper가 `_evaluation.log`를 기대해 실제 `_eval.log` 이름에서 멈췄다.
  생성된 metrics/report는 보존하고 날짜를 교정했으며 실제 경로로 감사를 완료했다.
  엔진 재실행/원시 판정 변경은 없었다. 감사는
  `relational_implementation_2026-09-08_v1_audit/results-audit.json`에 기록,
  `supports_exploratory_follow_up`, schema validator 통과. 같은 에이전트의 자체 감사다.
- 실행 종료 후 README/계획/증명/지원/인계 문서만 갱신했다. 동결 ZIP은 실행 당시 문서다.

**다음 TODO:** (1) 관계 경로의 시간 상한 없는 보장 명제와 기존 bounded/SMT 명제를
분리해 논문에 작성, (2) 초기 포함·전이/갱신·입력 분할·시간·폐쇄 증명 의무를 구현 근거에
연결, (3) 기존388 H=3.2초와 관계 개발6/20, corpus 신규 무제한0을 정확히 보고한다.
현재 구현에 corpus 전반의 H가 사라졌다고 쓰면 안 된다. 별도 승인 없이 abstract는 수정하지 않았다.


### H 없는 기존 자동 경로의 실제 자원 초과 예시 (2026-09-08, 후속 질문)

사용자가 실제 자원 초과 사례를 요청하여, 기존 exact 미완료 사례 중 긴 wait/delay
3건을 골라 기존 자동 Explorer에서 H만 None으로 바꿨다. 기존 cap(상태200000,
전이500000, 입력조합100000), process20초/768MiB 유지. 전체388 평가나 성능 실험이 아니다.

- C10_001: EQUIV-FIXPOINT,2400상태. C12_001: EQUIV-FIXPOINT,2401상태.
- C08_011: UNKNOWN/INCONCLUSIVE,126004상태,양쪽 실행 합1000000회(곱 상태 전이500000회),
  transition cap reached. 1시간 delay와 비동기 대기 시작을 구체 상대 타이머 값으로 보존한다.
- C08_011 IR은 Main_MB.button3만 기다리지만, code의 all-selector + ==|는 접지 후
  Main_MB 또는 Hall_MB의 pushed를 기다린다. 시작 시점 차이로 양쪽 타이머가 달라질 수 있다.
  3.2초 결과는 한 시간 뒤 ACTION에 대한 보장이 아니다.
- 기존 H=3.2초388건에서 Explorer 자원 초과는0건, exact 비교기의 state cap은13건이다.
  새 관계 경로 전건 시도의 진입0/인증0과 이번 기존 자동 경로의 H 없는 인증2건을 구분한다.
- 근거: eval/results/unbounded_resource_examples_2026-09-08_v1.json.
  엔진/기존 protocol/후보/평가 결과는 수정하지 않았다.


### Compact 인계 — H 제거 우선순위 확정 (2026-09-08)

**최신 작업 기준: [UNBOUNDED_TIME_HANDOFF.md](UNBOUNDED_TIME_HANDOFF.md).**
사용자 요청으로 결정/수정 대상을 저장했다. 이 턴에는 엔진 구현/재평가를 하지 않았다.

- 목표는 H 없는 검증. 논문 명제 연결보다 시간 처리 개선과 전체 H 없는 평가를 우선한다.
-100ms는 외부 입력 변화 간격, 코드 period가 아니다. C08_011은 period0.
- delay 중인 실행기는 입력을 읽지 않으므로 양쪽 비관찰 대기 구간의 매100ms 탐색은
  생략 대상으로 삼는다. 한쪽이 wait 중이면 그쪽의 관련 입력은 계속 고려해야 한다.
- 생략 후 재개 시 허용 최신 입력/격자 사이 보유 값/입력-만료 동률 우선순위를 보존한다.
  시작 때의 입력을 임의로 고정하거나 저장된 snapshot/edge 상태를 버리지 않는다.
- delay 진입 조건/시각/길이/재개 순서를 내부 검증 관찰로 비교하는 방향. 외부 ACTION
  정의 변경은 아니다. 내부 차이는 보수적 거절이고 ACTION 반례 재생이 있어야 DIVERGE.
- 이 비교만 붙여도 H가 제거되는 것은 아니다. 시간 이벤트 생략과 관계 상태 병합·폐쇄를
  연결한다. 시간 추상화 자료구조/정확한 알고리즘은 아직 미선택·미구현이다.
- C08_011은 복도만 pushed,거실은 계속 미입력인 이력을 유지하여1시간 만료로 가면
  코드만 ACTION을 내는 반례 후보다. 아직 압축 반례 재생을 수행하지 않았으며 저장된
  자동 Explorer 결과는 transition cap UNKNOWN이다. 다음 구현에서 구체 재생할 것.
- 카운터 관계는 이미 구현 완료. 매 회차 ACTION 변화와 양쪽 ACTION 불일치를 혼동하지 않는다.
- H 없는 기존 자동3건 진단의 인증2건과 관계 경로 전건 신규 인증0을 구분한다.
- 정확한 지원 명제·기존 SMT·BOOL/input/time/binding 계약은 유지. 자원 미완료를 인증으로
  처리하거나 이전208 bounded를 무제한으로 승격하지 않는다. 후보 재생성은 필요 없다.

다음 시작점: `timed.py:next_time/transition`, `ir_step.py`, `pause.py`, `runner.py`의
현재 위치별 입력 의존성/대기·재개를 확인하고, C08_011 및 양쪽 긴 delay 사례부터 고친다.

### 최신 완료 — H 없는 시간 탐색·전체 평가 (2026-09-08)

후속 사용자 승인으로 시간 개선과 H=None 전체 평가를 완료했다.
[최신 인계](UNBOUNDED_TIME_HANDOFF.md), [구현/증명 의무](UNBOUNDED_TIME.md),
[전체 결과](eval/results/unbounded_corpus_2026-09-08_v2/report.md)가 현재 기준이다.

- 양쪽 고정 delay/period의 비관찰 입력 사건을 생략하고, 만료 시 모든 최신 입력을
  검사한다.100ms 입력 격자,1ms 만료, 저장된 snapshot, 현재 실행 위치/타이머는 보존한다.
  정확한 상대 타이머와 입력 위상을 사용하며 서로 다른 남은 시간을 임의로 합치지 않는다.
- 고정 입력 이력의 단순/지속/edge/timeout wait 사건 가속은 반례 탐색에만 사용한다.
  timed 반례는 유효 입력 격자와 필수 중간 사건을 복원해 재생한다. C08_011 실제1시간
  반례, C20_005 실제59초 반례를 확인했다. 일반 BFS의 변화하는 입력 이력은 유지한다.
- 무제한 auto에서 엄격한 카운터 관계를 선택할 수 있다. SMT의 H 요구를 제거했지만
  모든 기호 경로가 종료해야 무제한 긍정 인증한다. 미완료는 UNKNOWN이다.
- **274개 회귀 전부 통과**, E1 563이력/변이2개/실패0.
  검증 기록은 `unbounded_time_validation_2026-09-08_v3.json`을 사용한다.
- **최종 v2 전체388:** EQUIV-FIXPOINT187 / 재생 DIVERGE95 / TIMEOUT2 /
  REFUSED43 / 기존 GENERATION_ERROR59 / PREPARATION_ERROR2. LLM0회, 약64.54초.
  이전 bounded 동등208 중187 새 인증,19는3.2초보다 뒤의 실제 ACTION 반례,
  2는clock 무한 반복 미완료다. 이전 불일치76건은 모두 유지됐다.
- 프로토콜/후보/입력 모델 비교,119개 소스와 후보 SHA 전후 연속성, 긍정 폐쇄/무H 필드,
  모든 불일치 재생을 확인했다. 원시/초록/IR/catalog/dataset/후보는 바꾸지 않았다.
  실행 이후 문서 갱신은 frozen ZIP과 구분한다.
- 첫 v1 corpus는 인증187/불일치86/미완료11. 후속 검토에서 커스텀 래퍼가 내부 delay와
  별도로 ACTION을 내는 합성 예제의 허위 bounded 인증을 발견했다. 정확히 알려진3종
  래퍼만 생략하도록 수정하고 재현/회귀로 고정했다. v2에서는 지속 조건 반례 탐색으로
  미완료9건도 실제 DIVERGE로 해결했다. v1은 보존하되 최종 근거로 사용하지 않는다.

**다음:** 무제한 보장 명제·각 경로의 충분조건/증명 의무·현재 결과를 논문에 연결.
남은 C15_005/C18_003은 clock 조건을 읽어 절대 시간이 누적되는 무한 반복이며 process
20초 상한이다. 불가능한 clock 조건의 증명된 상수화/관찰 clock 필드의 주기 관계가
후속 개선 후보다. 일반 비동기 타이머 region/zone 추상화와 모든 프로그램의 판정
가능성을 주장하지 않는다. 이 작업의 실험 감사도 동일 구현자의 자체 검토다.
[감사 기록](eval/results/unbounded_time_2026-09-08_audit/results-audit.md)은
supports_exploratory_follow_up이며 schema 검사를 통과했다. 이는 독립적인 수학적 인증이 아니다.

### 최신 완료 — catalog 범위와 clock2건 해결 (2026-09-08)

[범위 분석의 충분조건](CATALOG_RANGE_ANALYSIS.md)에 따라 Hour 0~23, Minute/Second 0~59를
명세화하고, 직접 읽기의 상수 정수 비교만 시간 의존성에서 제외했다. 원래 실행/저장소는
보존한다. **전체388: 인증189/재생 불일치95/미완료0/거절43/기존 생성 실패59/준비 오류2**,
나머지386건 판정 유지. **289회귀 통과**, LLM0회. [최신 결과](eval/results/catalog_ranges_corpus_2026-09-08_v1/report.md).
C15_005/C18_003은 IR과 코드 모두 자정 종료 조건을 잘못 쓴 reference 품질 이슈가 있으며,
이번 동등 인증을 자연어 의도의 정답성으로 해석하지 않는다. 다음은 논문 보장·증명·평가 연결.
