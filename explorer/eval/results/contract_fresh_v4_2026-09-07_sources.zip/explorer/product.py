"""Lockstep product exploration: base × variant equivalence checking.

Both programs run on the SAME input-cell sequence and the SAME time axis;
each transition executes one tick of each and compares the emitted actions
(device calls and GV writes — the full observable channel). A reachable
state where the outputs differ is a divergence, reported with the input
path that reaches it. If the product graph closes with no divergence, the
two programs are output-equivalent for every input sequence and unbounded
time, within the fragment.

Cells/thresholds are the UNION of both sides' predicates, so the input
partition is fine enough for whichever program distinguishes more.

Run:  python -m explorer.product   (self-checks + seeded fault variants)
"""

from __future__ import annotations

import itertools
import time as _time
from dataclasses import dataclass, field

from .explore import (Axes, T0_DEFAULT, _regs_frozen, next_event_ms,
                      next_key_change_ms, normalize, reps_from_preds)
from .interp import Unsupported
from .runner import JoiRunner, TerminalRunner

STATE_CAP = 400_000
STEP_CAP = 4_000_000


def merge_axes(a: Axes, b: Axes) -> Axes:
    truthy = set(a.truthy_reads) | set(b.truthy_reads)
    # (op, const) 술어는 합집합으로 보존한다 — replay의 cell_of가 관측값을
    # 셀에 넣을 때 필요 (이전엔 병합에서 유실됐음, 2026-09-02 수정).
    preds: dict[str, list] = {}
    for k in set(a.cell_preds) | set(b.cell_preds):
        preds[k] = sorted(set(map(tuple, a.cell_preds.get(k, [])))
                          | set(map(tuple, b.cell_preds.get(k, []))))
        if k in truthy:
            preds[k] = sorted(set(preds[k]) | {("!=", 0.0)})
    cells: dict[str, list] = {}
    for k in set(a.cells) | set(b.cells):
        if k in preds:
            # 수치 키는 술어 합집합에서 대표값을 다시 만든다. 양쪽 대표값의
            # 합집합만으로는 조합이 갈라놓는 구간을 놓친다 (A: x>10,
            # B: x>10.4 → (10, 10.4] 구간에 대표값 없음 → 허위 EQUIV).
            cells[k] = reps_from_preds(preds[k])
        else:
            cells[k] = sorted(set(a.cells.get(k, [])) | set(b.cells.get(k, [])),
                              key=repr)
    caps = dict(a.counter_caps)
    for k, v in b.counter_caps.items():
        caps[k] = max(caps.get(k, 0), v)
    merged = Axes(cells,
                sorted(set(a.hours) | set(b.hours)),
                a.weekdays_used or b.weekdays_used,
                a.holiday_used or b.holiday_used,
                sorted(set(a.ts_thresholds) | set(b.ts_thresholds)),
                caps,
                a.param_reads + b.param_reads,
                sorted(set(a.mirror_gv) | set(b.mirror_gv)),
                minutes=sorted(set(a.minutes) | set(b.minutes)),
                hour_ops=sorted(set(a.hour_ops) | set(b.hour_ops)),
                cell_preds=preds,
                tod_ops=sorted(set(map(tuple, a.tod_ops))
                               | set(map(tuple, b.tod_ops))),
                observable_reads=sorted(set(a.observable_reads) | set(b.observable_reads)),
                truthy_reads=sorted(truthy))
    from .input_coverage import merged_coverage, install_coverage
    return install_coverage(merged, merged_coverage(a.coverage, b.coverage))


def check_supported_pair(runner_a, runner_b, axes: Axes | None = None,
                         input_domains: dict | None = None) -> Axes:
    """Apply every fail-closed supported-fragment precondition."""
    axes = axes or merge_axes(runner_a.axes, runner_b.axes)
    if axes.coverage.errors:
        raise Unsupported("input coverage: " + "; ".join(sorted(set(axes.coverage.errors))))
    if axes.param_reads:
        raise Unsupported(f"parameterized reads: {axes.param_reads}")
    bad = runner_a.check_finite(axes) + runner_b.check_finite(axes)
    if bad:
        raise Unsupported(f"unbounded carried vars: {bad}")
    from .features import analyze_runner, enforce
    enforce(analyze_runner(runner_a) + analyze_runner(runner_b))
    missing = set(axes.observable_reads) - set(input_domains or {})
    if missing:
        raise Unsupported("explicit input domain required for observable value flow: "
                          + ", ".join(sorted(missing)))
    missing = set(axes.exact_reads) - set(input_domains or {})
    if missing:
        raise Unsupported("explicit input domain required for non-partitionable value flow: "
                          + ", ".join(sorted(missing)))
    if input_domains is not None:
        from .input_model import validate_domains
        validate_domains(input_domains, required=axes.cells)
        conflicts = {key for key in input_domains if key.startswith("@gv:")
                     and key[4:] in axes.coverage.writes}
        if conflicts:
            raise Unsupported("written GVs are initial state, not changing external inputs: "
                              + ", ".join(sorted(conflicts)))
    return axes


@dataclass
class Divergence:
    depth: int              # transitions from an initial state
    input_: dict
    dwell_ms: int
    actions_a: tuple
    actions_b: tuple
    path: list              # [(input, dwell_ms), ...] up to the divergence
    initial_gv: dict | None = None
    t0_ms: int | None = None


@dataclass
class ProductResult:
    verdict: str            # "EQUIV" | "DIVERGE" | "UNKNOWN"(탐색 미완 —
                            # 게이트는 밖으로 REFUSED로 접는다, gate.py)
    n_states: int = 0
    n_steps: int = 0
    closed: bool = True
    divergences: list = field(default_factory=list)
    seconds: float = 0.0
    notes: list = field(default_factory=list)
    # None means the normal fixpoint/unbounded-within-fragment search.  A
    # positive value means every modeled history was checked only through
    # that many logical ticks; this is used solely by the A/B evaluation.
    bounded_horizon_ticks: int | None = None
    bounded_horizon_ms: int | None = None
    input_step_ms: int | None = None

    @property
    def claim(self):
        if self.verdict != "EQUIV":
            return "INCONCLUSIVE" if self.verdict == "UNKNOWN" else self.verdict
        return ("EQUIV-BOUNDED" if self.bounded_horizon_ticks is not None
                or self.bounded_horizon_ms is not None else "EQUIV-FIXPOINT")


@dataclass
class ReplayResult:
    confirmed: bool
    at_step: int = -1        # 몇 번째 걸음에서 실제로 갈라졌나 (0-기준)
    mirror_init: dict = field(default_factory=dict)
    actions_a: tuple = ()
    actions_b: tuple = ()
    note: str = ""


def replay_divergence(runner_a, runner_b, div: "Divergence",
                      t0_ms: int | None = None) -> ReplayResult:
    """반례 경로를 구체 상태로 되밟아 진짜 갈라짐인지 확인 (T2 복원).

    탐색(BFS)은 정규화된 상태(키 병합·과근사)를 걷기 때문에 DIVERGE가
    허위일 수 있다. 여기서는 병합 없이 실제 상태 dict를 끌고 기록된
    입력·시간 경로를 그대로 다시 실행한다. 어느 걸음에서든 양쪽 액션이
    실제로 다르면 확인(confirmed) — 반례 = 실행 가능한 입력 시퀀스.
    새 timed 반례는 실제 초기 GV/시각을 저장한다. 구 반례에는 초기값이
    없으므로 기존 mirror GV 조합을 전부 시도한다.
    """
    if t0_ms is None:
        t0_ms = div.t0_ms if div.t0_ms is not None else T0_DEFAULT
    runner_a, runner_b = TerminalRunner(runner_a), TerminalRunner(runner_b)
    axes = merge_axes(runner_a.axes, runner_b.axes)
    ext_gv = {k[4:] for k in axes.cells if k.startswith("@gv:")}
    seq = list(div.path) + [(div.input_, div.dwell_ms)]

    def split(i: dict) -> tuple[dict, dict]:
        return ({k: v for k, v in i.items() if not k.startswith("@gv:")},
                {k[4:]: v for k, v in i.items() if k.startswith("@gv:")})

    def own(gv: dict) -> dict:
        return {k: v for k, v in gv.items() if k not in ext_gv}

    if div.initial_gv is not None:
        mirror_inits = [div.initial_gv]
    else:
        from .input_coverage import initial_domains
        domains = initial_domains(axes)
        mirror_inits = [dict(zip(domains, vals)) for vals in
                        itertools.product(*domains.values())]
    for m in mirror_inits:
        gv0 = {k: v for k, v in m.items() if v is not None}
        av, ag = {}, dict(gv0)
        bv, bg = {}, dict(gv0)
        now = t0_ms
        for n, (i, d) in enumerate(seq):
            if i is None:        # 기록 없는 걸음(방어) — 재생 불가
                break
            w, gvs = split(i)
            now += d
            ra = runner_a.step(av, {**ag, **gvs}, w, now, first_tick=(n == 0))
            rb = runner_b.step(bv, {**bg, **gvs}, w, now, first_tick=(n == 0))
            if _out(ra.actions) != _out(rb.actions):
                return ReplayResult(True, n, gv0,
                                    _out(ra.actions), _out(rb.actions))
            if ra.terminated and rb.terminated:
                break            # 양쪽 다 종료했고 액션도 같았음 — 이 초기값은 실패
            av, ag = ra.vars, own(ra.gv)
            bv, bg = rb.vars, own(rb.gv)
    return ReplayResult(False, note="재생에서 갈라짐 없음 — 허위 반례 의심")


def _canon(v):
    """비교용 인자 표기 통일: 100.0(JSON)과 100(코드)은 같은 값."""
    return int(v) if isinstance(v, float) and v.is_integer() else v


def _freeze_concrete(value):
    """Hashable, lossless store key for bounded evaluation mode."""
    from .state_key import freeze_state
    return freeze_state(value)


def _out(actions) -> tuple:
    from .observation import actions_observation
    return actions_observation(actions)


def product_explore(src_a: str | list, src_b: str | list, period_ms: int,
                    t0_ms: int | None = None,
                    max_diverge: int = 3,
                    max_ticks: int | None = None) -> ProductResult:
    """JoI × JoI 진입점 — 실행기(Runner)로 감싸 본체에 넘긴다."""
    return product_runners(JoiRunner.from_src(src_a), JoiRunner.from_src(src_b),
                           period_ms, t0_ms, max_diverge, max_ticks)


def product_runners(runner_a, runner_b, period_ms: int,
                    t0_ms: int | None = None,
                    max_diverge: int = 3,
                    max_ticks: int | None = None,
                    input_domains: dict | None = None) -> ProductResult:
    """실행기 두 개를 나란히 걸으며 액션을 대조한다.

    ``max_ticks`` is an evaluation-only bounded mode.  When present, the
    initial reaction is tick 1 and no successor later than tick ``max_ticks``
    is executed.  Elapsed time is included in the visited key in this mode so
    a state first reached late cannot hide the same state reached earlier with
    more remaining horizon.
    """
    t_start = _time.time()
    t0_ms = T0_DEFAULT if t0_ms is None else t0_ms
    if period_ms <= 0:
        raise ValueError("period_ms must be positive")
    if max_ticks is not None and max_ticks <= 0:
        raise ValueError("max_ticks must be positive")
    horizon_end = (None if max_ticks is None
                   else t0_ms + (max_ticks - 1) * period_ms)
    runner_a, runner_b = TerminalRunner(runner_a), TerminalRunner(runner_b)
    va, vb = runner_a.vars_info, runner_b.vars_info
    axes = check_supported_pair(runner_a, runner_b, input_domains=input_domains)
    if input_domains is not None:
        from dataclasses import replace
        from .input_model import validate_domains
        validate_domains(input_domains, required=set(axes.cells))
        axes = replace(axes, cells={k: list(v) for k, v in input_domains.items()})

    res = ProductResult("EQUIV", bounded_horizon_ticks=max_ticks)
    keys = sorted(axes.cells)
    combos = [dict(zip(keys, vals))
              for vals in itertools.product(*(axes.cells[k] for k in keys))]
    if not combos:
        combos = [{}]
    from .feasibility import dedup_combos
    if input_domains is None and hasattr(runner_a, "stmts") and hasattr(runner_b, "stmts"):
        combos, dd = dedup_combos([(runner_a.stmts, va), (runner_b.stmts, vb)],
                                  combos)
        if dd.after < dd.before:
            res.notes.append(f"combo dedup {dd.before}→{dd.after}")
    ext_gv = {k[4:] for k in axes.cells if k.startswith("@gv:")}

    def split(i: dict) -> tuple[dict, dict]:
        return ({k: v for k, v in i.items() if not k.startswith("@gv:")},
                {k[4:]: v for k, v in i.items() if k.startswith("@gv:")})

    def own(gv: dict) -> dict:
        return {k: v for k, v in gv.items() if k not in ext_gv}

    visited: dict[tuple, None] = {}
    # key → (parent_key|None, input, dwell, 반복 수) — 반복 수 n은 같은
    # (input, dwell) 한-tick 걸음이 n번 이어졌다는 뜻(점프 억제 시의
    # 실걸음 fast-forward). 재생은 걸음 단위라 경로 전개 때 n번 편다.
    parents: dict[tuple, tuple] = {}
    queue: list = []                      # (A_vars, A_gv, B_vars, B_gv, now, held)

    def key_of(av, ag, bv, bg, now) -> tuple:
        if horizon_end is not None:
            # A bounded accuracy experiment must not merge two concrete timer
            # ages merely because they occupy the same threshold zone.  At the
            # same wall time, age 1 and age 2 can have different behavior before
            # the horizon even though both satisfy ``age < 3``.  Keep the raw
            # stores and depth; bounded mode evaluates only the input-value
            # partition, not state/time abstraction.
            return (_freeze_concrete(av), _freeze_concrete(ag),
                    _freeze_concrete(bv), _freeze_concrete(bg), now - t0_ms)
        return (normalize(av, ag, now, va, axes),
                normalize(bv, bg, now, vb, axes))

    def push(av, ag, bv, bg, now, held, parent, i, d, rep: int = 1) -> None:
        k = key_of(av, ag, bv, bg, now)
        if k not in visited:
            visited[k] = None
            parents[k] = (parent, i, d, rep)
            queue.append((av, ag, bv, bg, now, held))

    def path_to(k) -> list:
        out = []
        while k is not None and k in parents:
            p, i, d, rep = parents[k]
            out.extend([(i, d)] * rep)
            k = p
        return list(reversed(out))

    WALK_CAP = 100_000        # 상태 하나의 실걸음 fast-forward 최대 tick 수

    def _drop(vars_, drift: set) -> dict:
        return {k: v for k, v in vars_.items() if k not in drift}

    def walk_time(av, ag, bv, bg, now, held, here) -> None:
        """점프 억제 상태의 시간 전진 보전 — 다음 키-변화 경계까지 실걸음.

        걸음마다 실제 step이라 낡은 레지스터 재생이 없다. 걷다가 키가
        바뀌거나 (양쪽 동일한) 발화가 나오면 그 상태를 밀어 BFS가 잇고,
        차이가 나오면 그대로 반례다(경로는 tick 단위로 편다).

        목표 경계는 now-추적(매 tick 갱신) 레지스터를 **빼고** 계산한다 —
        추적 레지스터의 교차점은 늘 한 tick 앞에서 다시 무장되는 신기루라
        그걸 목표로 삼으면 달력 경계까지 영영 못 간다. 어떤 레지스터가
        추적인지는 걸으면서 실측한다(값이 변한 timestamp 상태 변수).
        빼고도 남는 경계가 없으면 상태는 시간-이동 불변 — 재방문 종료가
        안전하다. 달력 경계는 절대 시각이라 녹지 않고 반드시 걸린다.
        경계가 걸음 예산 밖이면 닫힘 주장을 포기한다(→ UNKNOWN)."""
        for cand in [held] + combos:
            w, gvs = split(cand)
            wa, wag, wb, wbg, wnow = av, ag, bv, bg, now
            drift: set = set()
            target = None
            ticks = 0
            while ticks < WALK_CAP:
                if horizon_end is not None and wnow + period_ms > horizon_end:
                    break
                if target is None or wnow >= target:
                    targets = [t for t in (
                        next_key_change_ms(_drop(wa, drift), wnow, va, axes),
                        next_key_change_ms(_drop(wb, drift), wnow, vb, axes))
                        if t is not None]
                    if not targets:
                        break            # 남는 경계 없음 — 시간-이동 불변
                    target = min(targets)
                    if (target - wnow) // period_ms + 1 > WALK_CAP - ticks:
                        res.closed = False
                        note = "점프 억제 + 경계가 걸음 예산 밖 — 미완"
                        if note not in res.notes:
                            res.notes.append(note)
                        return
                if res.n_steps > STEP_CAP:
                    res.closed = False
                    if "CAP HIT" not in res.notes:
                        res.notes.append("CAP HIT")
                    return
                ra = runner_a.step(wa, {**wag, **gvs}, w, wnow + period_ms)
                rb = runner_b.step(wb, {**wbg, **gvs}, w, wnow + period_ms)
                res.n_steps += 2
                oa, ob = _out(ra.actions), _out(rb.actions)
                if oa != ob:
                    res.divergences.append(Divergence(
                        len(path_to(here)) + ticks + 1, cand, period_ms,
                        oa, ob,
                        path_to(here) + [(cand, period_ms)] * ticks))
                    return
                for nm, vi in va.items():   # 추적 레지스터 실측
                    if vi.timestamp and ra.vars.get(nm) != wa.get(nm):
                        drift.add(nm)
                for nm, vi in vb.items():
                    if vi.timestamp and rb.vars.get(nm) != wb.get(nm):
                        drift.add(nm)
                wnow += period_ms
                ticks += 1
                wa, wag = ra.vars, own(ra.gv)
                wb, wbg = rb.vars, own(rb.gv)
                if ra.terminated and rb.terminated:
                    break
                if oa or key_of(wa, wag, wb, wbg, wnow) != here:
                    push(wa, wag, wb, wbg, wnow, cand, here, cand,
                         period_ms, rep=ticks)
                    break

    from .input_coverage import initial_domains
    domains = initial_domains(axes)
    mirror_inits = [dict(zip(domains, vals)) for vals in itertools.product(*domains.values())]
    for i in combos:
        for m in mirror_inits:
            gv0 = {k: v for k, v in m.items() if v is not None}
            w, gvs = split(i)
            ra = runner_a.step({}, {**gv0, **gvs}, w, t0_ms, first_tick=True)
            rb = runner_b.step({}, {**gv0, **gvs}, w, t0_ms, first_tick=True)
            res.n_steps += 2
            if _out(ra.actions) != _out(rb.actions):
                res.divergences.append(Divergence(
                    0, i, 0, _out(ra.actions), _out(rb.actions), []))
                if len(res.divergences) >= max_diverge:
                    break
                continue
            if not (ra.terminated and rb.terminated):
                push(ra.vars, own(ra.gv), rb.vars, own(rb.gv), t0_ms, i,
                     None, i, 0)
        if len(res.divergences) >= max_diverge:
            break

    while queue and len(res.divergences) < max_diverge:
        if len(visited) > STATE_CAP or res.n_steps > STEP_CAP:
            res.notes.append("CAP HIT")
            res.closed = False
            break
        av, ag, bv, bg, now, held = queue.pop(0)
        here = key_of(av, ag, bv, bg, now)
        if horizon_end is not None and now >= horizon_end:
            continue

        # stutter witness (see explore.py): some holdable input must keep
        # BOTH sides silent and stationary for a long dwell to be legal
        stutter = False
        suppressed = False
        if horizon_end is None:
            for cand in [held] + combos:
                w, gvs = split(cand)
                pa = runner_a.step(av, {**ag, **gvs}, w, now + period_ms)
                pb = runner_b.step(bv, {**bg, **gvs}, w, now + period_ms)
                res.n_steps += 2
                if (not pa.actions and not pb.actions
                        and not pa.terminated and not pb.terminated
                        and key_of(pa.vars, own(pa.gv), pb.vars, own(pb.gv),
                                   now + period_ms) == here):
                    # explore.py와 동일한 안전 조건: now를 따라가는 레지스터는
                    # 정규화 키에선 정지해 보여도 구체값이 흐른다 — 점프가
                    # 낡은 레지스터로 재생되며 없는 발화를 지어낸다. 양쪽 다
                    # 얼어 있을 때만 점프 (2026-09-02 수정; 이전엔 product에
                    # 이 가드가 없어 explore와 판정이 어긋날 수 있었음).
                    if not (_regs_frozen(av, pa.vars, va)
                            and _regs_frozen(bv, pb.vars, vb)):
                        note = "jump suppressed: now-tracking register"
                        if note not in res.notes:
                            res.notes.append(note)
                        suppressed = True
                        continue
                    stutter = True
                    break
        dwells = [period_ms]
        if stutter:
            for ev in (next_event_ms(av, now, va, axes),
                       next_event_ms(bv, now, vb, axes),
                       next_key_change_ms(av, now, va, axes),
                       next_key_change_ms(bv, now, vb, axes)):
                if ev is not None and ev - now > period_ms:
                    pre = ((ev - now) // period_ms) * period_ms
                    for d in (pre, pre + period_ms):
                        if d > period_ms and d not in dwells:
                            dwells.append(d)

        for i in combos:
            w, gvs = split(i)
            for d in dwells:
                if horizon_end is not None and now + d > horizon_end:
                    continue
                ra = runner_a.step(av, {**ag, **gvs}, w, now + d)
                rb = runner_b.step(bv, {**bg, **gvs}, w, now + d)
                res.n_steps += 2
                if _out(ra.actions) != _out(rb.actions):
                    res.divergences.append(Divergence(
                        len(path_to(here)) + 1, i, d,
                        _out(ra.actions), _out(rb.actions), path_to(here)))
                    if len(res.divergences) >= max_diverge:
                        break
                    continue
                if not (ra.terminated and rb.terminated):
                    push(ra.vars, own(ra.gv), rb.vars, own(rb.gv), now + d, i,
                         here, i, d)
            if len(res.divergences) >= max_diverge:
                break

        # 점프가 억제됐고 tick 후속들이 같은 키로 접히면 시간 전진이
        # 통째로 사라진다 (달력 경계 뒤의 행동이 영원히 미탐 → 허위
        # EQUIV — E3 C18_007에서 발견, 2026-09-02). 실걸음 fast-forward:
        # 입력을 고정한 채 다음 키-변화 경계까지 한 tick씩 실제로 걷는다.
        # 레지스터가 매 tick 충실히 갱신되므로 점프의 조작이 없다.
        if suppressed and not stutter and len(res.divergences) < max_diverge:
            walk_time(av, ag, bv, bg, now, held, here)

    res.n_states = len(visited)
    res.closed = res.closed and not queue
    if res.divergences:
        res.verdict = "DIVERGE"
    elif not res.closed:
        # "어긋남을 못 봤다"와 "같음을 확인했다"는 다르다 — cap 등으로
        # 그래프가 닫히지 않았으면 EQUIV를 주장하지 않는다 (2026-09-02).
        res.verdict = "UNKNOWN"
    res.seconds = _time.time() - t_start
    return res


# ── Driver: self-equivalence + seeded fault variants ─────────────────────────

def _show(name: str, r: ProductResult, replay_with=None) -> None:
    print(f"{name[:44]:44s} {r.verdict:8s} 상태={r.n_states:<6d} "
          f"step={r.n_steps:<7d} {r.seconds:5.2f}s "
          f"{'닫힘' if r.closed else '미완'} {' '.join(r.notes)}")
    for dv in r.divergences[:2]:
        ia = {k.split(':')[-1].split('.')[-1]: v for k, v in dv.input_.items()}
        print(f"    ↳ 반례: 깊이 {dv.depth}, 입력 {ia}, dwell {dv.dwell_ms/1000:.0f}s")
        print(f"      base : {list(dv.actions_a) or '(무발화)'}")
        print(f"      변형 : {list(dv.actions_b) or '(무발화)'}")
        if replay_with:
            rr = replay_divergence(replay_with[0], replay_with[1], dv)
            tag = (f"확인 (걸음 {rr.at_step})" if rr.confirmed
                   else f"허위? {rr.note}")
            print(f"      재생 : {tag}")


def main() -> None:
    import json
    data = json.load(open("explorer/corpus/joi_automation_codes.json"))
    by_name = {s["name"]: s for s in data}

    print("== 자기동치 (base × base → 전부 EQUIV여야 함) ==")
    for s in data:
        if s.get("cron") not in ("", "x", None):
            continue
        try:
            r = product_explore(s["code"], s["code"], int(s["period"]))
            _show(s["name"], r)
        except Unsupported as e:
            print(f"{s['name'][:44]:44s} —        Unsupported: {e}")

    def mutate(code: str, old: str, new: str) -> str:
        out = code.replace(old, new)
        assert out != code, f"no-op mutation: {old!r} not found"
        return out

    print("\n== 고장 주입 변형 (전부 DIVERGE + 재생 확인이어야 함) ==")

    def show_mut(name: str, base_src: str, mut_src: str, period: int) -> None:
        try:
            ra = JoiRunner.from_src(base_src)
            rb = JoiRunner.from_src(mut_src)
            _show(name, product_runners(ra, rb, period), replay_with=(ra, rb))
        except Unsupported as e:
            print(f"{name[:44]:44s} —        Unsupported: {e}")

    fire = by_name["화재 감지 알림"]
    mut1 = mutate(fire["code"], "30 * 60", "3 * 60")
    show_mut("화재: cooldown 30분→3분 (단위류 오류)",
             fire["code"], mut1, int(fire["period"]))

    sec = by_name["보안모드 자동제어"]
    mut2 = sec["code"].replace(
        "if (pushed == true and was_pushed == false)",
        "if (pushed == true)")
    show_mut("보안모드: 엣지→레벨 (was_pushed 조건 삭제)",
             sec["code"], mut2, int(sec["period"]))

    intr = by_name["보안모드 침입 감지"]
    mut3 = intr["code"].replace("now - grace_start > grace_sec",
                                "now - grace_start >= grace_sec")
    show_mut("침입: grace 경계 > → >= (1 tick 조기 발화)",
             intr["code"], mut3, int(intr["period"]))

    mut4 = intr["code"].replace("alert_cooldown := 600",
                                "alert_cooldown := 60")
    show_mut("침입: cooldown 600→60 (재알림 폭주)",
             intr["code"], mut4, int(intr["period"]))


if __name__ == "__main__":
    main()
