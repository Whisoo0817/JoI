"""Repository-local, append-only contract evaluation; no candidate selection by outcome.

Run from repository root. Protocol precedes generation; preparation freezes domains
before either search. Each engine gets its own process and identical model/caps.
"""
import argparse
from collections import Counter
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        json.dump(data, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write('\n')


def snapshot():
    from timeline_ir.catalog import load_service_specs
    paths = set(Path('explorer').glob('*.py'))
    for base in ('lowering', 'timeline_ir'):
        paths.update(p for p in Path(base).rglob('*') if p.is_file()
                     and p.suffix in ('.py', '.json', '.md', '.txt', '.g4'))
    paths.update(Path('explorer').glob('*.md'))
    paths.update((Path(__file__).resolve().relative_to(ROOT), Path('dataset.csv'),
                  Path(load_service_specs()['path'])))
    return {str(p): sha(p) for p in sorted(paths)}


def verify(sources):
    bad = [p for p, digest in sources.items() if not Path(p).exists() or sha(p) != digest]
    if bad:
        raise RuntimeError('snapshot mismatch: ' + ', '.join(bad))


def protocol(args):
    from explorer.e3 import load_rows, key_of
    rows = sorted(load_rows(), key=key_of)
    if args.pilot:
        selected = {}
        for r in rows:
            selected.setdefault(r['category_v2'], r)
        rows = list(selected.values())[:5]
    write(args.output, {
        'schema_version': 1, 'semantics': 'contract-v1',
        'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'evidence_class': 'development-pilot' if args.pilot else 'fresh-generation-on-familiar-tasks',
        'selection_rule': 'first case of first five categories, sorted IDs' if args.pilot else
                          'all dataset rows with category_v2 and ir_gt; no outcome exclusions',
        'case_ids': [key_of(r) for r in rows], 'candidates': args.candidates,
        'generation': {'model': 'cyankiwi/gemma-4-26B-A4B-it-AWQ-4bit',
                       'workers': 4, 'timeout_seconds': 120, 'seed': None,
                       'pipeline': 'explorer.e3 gen; gold IR injected; mapping/lowering generated',
                       'sampling': 'existing pipeline stage temperatures frozen by source hashes'},
        'model_policy': {'horizon_ms': 3200, 'input_step_ms': 100, 't0_ms': 2419200000,
                         'service_catalog': True,
                         'input_basis': 'catalog-backed joint certified representatives; exact observable domains; None included; DOUBLE lattice 0.1',
                         'gv_basis': 'normative predicate-family initial/external GV domains; no measured store claim; required explicit domains unavailable => REFUSED',
                         'bindings': 'dataset binding_gt and fixed connected_devices; no rebinding'},
        'caps': {'max_states': 200000, 'max_transitions': 500000, 'max_input_combinations': 100000},
        'engine_limits': {'wall_seconds': 20, 'address_space_mib': 768},
        'evaluation_workers': 1, 'engine_order': ['explorer', 'exact'],
        'stop_rule': 'run every selected case once per engine; no automatic scientific retries; retain refusal, invalid, timeout, memory failure and disagreement',
        'sources': snapshot(), 'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'environment': {'python': sys.version, 'platform': platform.platform(),
                        'cpu': next((x.split(':', 1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')), 'unknown')},
        'limitations': ['repository digest continuity is not filesystem isolation',
                        'familiar tasks are not unseen-task heldout',
                        'search engines share adapters and observation; no independent ground truth labels',
                        '3.2 seconds is a bounded evaluation horizon, not a completeness bound']})


def prepare(args):
    from explorer.e3 import load_rows, key_of
    from explorer.gate import prepare_pair, pair_input_domains
    from explorer.product import check_supported_pair
    from explorer.input_coverage import initial_domains
    from explorer.interp import Unsupported
    p = json.loads(Path(args.protocol).read_text())
    verify(p['sources'])
    rows = {key_of(r): r for r in load_rows()}
    cases = []
    for key in p['case_ids']:
        row = rows[key]
        path = Path(p['candidates']) / (key + '.json')
        c = {'id': key, 'candidate_path': str(path), 'status': 'GENERATION_ERROR'}
        cases.append(c)
        if not path.exists():
            c['reason'] = 'missing candidate artifact (generation timeout/crash or not attempted; see generation log)'
            continue
        c['candidate_sha256'] = sha(path)
        try:
            candidate = json.loads(path.read_text())
            if candidate.get('status') != 'ok' or not isinstance(candidate.get('joi_block'), dict):
                c['reason'] = candidate.get('error_code', 'missing joi_block')
                continue
            c['payload'] = {'ir': json.loads(row['ir_gt']), 'binding': json.loads(row.get('binding_gt') or '{}'),
                            'devices': json.loads(row['connected_devices']), 'joi_block': candidate['joi_block']}
            payload = c['payload']
            pair = prepare_pair(payload['ir'], payload['binding'], payload['devices'], payload['joi_block'])
            domains = pair_input_domains(pair)
            axes = check_supported_pair(pair.ir_runner, pair.code_runner, input_domains=domains)
            c['model'] = {k: p['model_policy'][k] for k in ('horizon_ms', 'input_step_ms', 't0_ms')}
            c['model'].update(input_domains=domains, initial_gv_domains=initial_domains(axes))
            c.update(status='READY', input_families=axes.input_families,
                     domain_basis=p['model_policy']['input_basis'], gv_basis=p['model_policy']['gv_basis'],
                     service_model=pair.service_model.evidence(), preparation_notes=pair.notes)
        except Unsupported as e:
            c.update(status='REFUSED', reason=str(e))
        except Exception as e:
            c.update(status='PREPARATION_ERROR', reason=type(e).__name__ + ': ' + str(e))
    verify(p['sources'])
    write(args.output, {'protocol_path': args.protocol, 'protocol_sha256': sha(args.protocol), 'cases': cases})
    print(json.dumps(dict(Counter(c['status'] for c in cases)), ensure_ascii=False), flush=True)


def worker(args):
    job = json.load(sys.stdin)
    limit = job['limits']['address_space_mib'] * 1024**2
    resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
    started = time.perf_counter()
    result = {'status': 'ERROR'}
    try:
        from explorer.gate import prepare_pair
        from explorer.interp import Unsupported
        from explorer.exact_timed import exact_timed_product
        from explorer.timed import timed_product
        from explorer.product import replay_divergence
        payload = job['case']['payload']
        pair = prepare_pair(payload['ir'], payload['binding'], payload['devices'], payload['joi_block'])
        engine = timed_product if args.engine == 'explorer' else exact_timed_product
        r = engine(pair.ir_runner, pair.code_runner, **job['case']['model'], **job['caps'])
        result = {'status': r.verdict, 'result': asdict(r)}
        if args.engine == 'explorer':
            result['claim'] = r.claim
            result['replays'] = [asdict(replay_divergence(pair.ir_runner, pair.code_runner, d)) for d in r.divergences]
            if r.verdict == 'DIVERGE' and not any(x['confirmed'] for x in result['replays']):
                result['status'] = 'REPLAY_UNCONFIRMED'
    except MemoryError:
        result = {'status': 'MEMORY_LIMIT'}
    except Unsupported as e:
        result = {'status': 'REFUSED', 'reason': str(e)}
    except Exception as e:
        result = {'status': 'ERROR', 'reason': type(e).__name__ + ': ' + str(e)}
    result.update(worker_seconds=time.perf_counter() - started,
                  peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    print(json.dumps(result, ensure_ascii=False, default=repr), flush=True)


def run(args):
    p = json.loads(Path(args.protocol).read_text())
    m = json.loads(Path(args.manifest).read_text())
    if m['protocol_sha256'] != sha(args.protocol):
        raise RuntimeError('protocol mismatch')
    verify(p['sources'])
    for c in m['cases']:
        if 'candidate_sha256' in c and sha(c['candidate_path']) != c['candidate_sha256']:
            raise RuntimeError('candidate mismatch: ' + c['id'])
    dest = Path(args.output)
    dest.mkdir(parents=True, exist_ok=False)
    outcomes = []
    started = time.perf_counter()
    with (dest / 'case_outcomes.jsonl').open('x') as log:
        for c in m['cases']:
            row = {'id': c['id'], 'status': c['status']}
            if c['status'] == 'READY':
                for engine in p['engine_order']:
                    tick = time.perf_counter()
                    job = {'case': c, 'caps': p['caps'], 'limits': p['engine_limits']}
                    try:
                        proc = subprocess.run([sys.executable, __file__, 'worker', '--engine', engine],
                                              input=json.dumps(job), text=True, capture_output=True,
                                              timeout=p['engine_limits']['wall_seconds'])
                        row[engine] = json.loads(proc.stdout) if proc.returncode == 0 else {
                            'status': 'CRASH', 'returncode': proc.returncode, 'stderr': proc.stderr[-2000:]}
                    except subprocess.TimeoutExpired:
                        row[engine] = {'status': 'TIMEOUT', 'peak_rss_kib': None}
                    except Exception as e:
                        row[engine] = {'status': 'HARNESS_ERROR', 'reason': str(e)}
                    row[engine]['process_wall_seconds'] = time.perf_counter() - tick
                a, b = row['explorer']['status'], row['exact']['status']
                complete = a in ('EQUIV', 'DIVERGE') and b in ('EQUIV_BOUNDED', 'DIVERGE')
                row['status'] = ('AGREE' if (a == 'DIVERGE') == (b == 'DIVERGE') else 'DISAGREEMENT') if complete else 'NOT_COMPARABLE'
            else:
                row['reason'] = c.get('reason')
            outcomes.append(row)
            log.write(json.dumps(row, ensure_ascii=False, default=repr) + '\n')
            log.flush()
            print(f"[{len(outcomes)}/{len(m['cases'])}] {c['id']} {row['status']} " +
                  ' '.join(e + '=' + row[e]['status'] for e in p['engine_order'] if e in row), flush=True)
    verify(p['sources'])
    for c in m['cases']:
        if 'candidate_sha256' in c and sha(c['candidate_path']) != c['candidate_sha256']:
            raise RuntimeError('candidate changed during evaluation: ' + c['id'])
    summary = {'protocol_sha256': sha(args.protocol), 'manifest_sha256': sha(args.manifest),
               'outcomes_sha256': sha(dest / 'case_outcomes.jsonl'), 'snapshot_continuity': True,
               'total_cases': len(outcomes), 'statuses': dict(Counter(r['status'] for r in outcomes)),
               'wall_seconds': time.perf_counter() - started, 'engines': {},
               'evidence_class': p['evidence_class'], 'model_policy': p['model_policy']}
    for engine in p['engine_order']:
        values = [r[engine] for r in outcomes if engine in r]
        times = sorted(r['result']['seconds'] for r in values if 'result' in r)
        summary['engines'][engine] = {'statuses': dict(Counter(r['status'] for r in values)),
                                     'returned_search_seconds_n': len(times),
                                     'returned_search_seconds_median': statistics.median(times) if times else None,
                                     'returned_search_seconds_max': max(times) if times else None,
                                     'note': 'conditional on returned search results; not all-case latency; per-case process wall and peak RSS in JSONL'}
    write(dest / 'summary.json', summary)
    print(json.dumps(summary, ensure_ascii=False), flush=True)


def main():
    os.chdir(ROOT)
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('protocol')
    p.add_argument('--candidates', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--pilot', action='store_true')
    p = sub.add_parser('prepare')
    p.add_argument('--protocol', required=True)
    p.add_argument('--output', required=True)
    p = sub.add_parser('run')
    p.add_argument('--protocol', required=True)
    p.add_argument('--manifest', required=True)
    p.add_argument('--output', required=True)
    p = sub.add_parser('worker')
    p.add_argument('--engine', choices=('explorer', 'exact'), required=True)
    args = ap.parse_args()
    globals()[args.cmd](args)


if __name__ == '__main__':
    main()
